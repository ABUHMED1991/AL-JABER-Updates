@echo off
cd /d "%~dp0"
py updater.py
if errorlevel 1 pause
