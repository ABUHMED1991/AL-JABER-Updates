"""Build an UPDATER-compatible ZIP from an already-built main EXE."""
import hashlib,json,sys,zipfile
from pathlib import Path
if __name__=='__main__':
    if len(sys.argv)!=3:
        print('Usage: py make_update.py VERSION path/to/ALJABER_Concrete_2026.exe');sys.exit(2)
    version, exe = sys.argv[1], Path(sys.argv[2])
    if not exe.is_file() or exe.name!='ALJABER_Concrete_2026.exe':
        raise SystemExit('Choose a built ALJABER_Concrete_2026.exe')
    contents={exe.name:exe.read_bytes()}
    manifest={'schema':1,'product':'AL-JABER Concrete 2026','version':version,
              'files':{k:hashlib.sha256(v).hexdigest() for k,v in contents.items()}}
    out=Path(f'ALJABER_update_{version}.zip')
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False))
        for k,v in contents.items():z.writestr(k,v)
    print('Created',out)
