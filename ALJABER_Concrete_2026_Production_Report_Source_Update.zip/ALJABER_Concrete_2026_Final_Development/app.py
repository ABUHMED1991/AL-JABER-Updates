import sys, os, re, sqlite3, traceback, logging
from pathlib import Path
from translations import LANGUAGES, LANGUAGE_CODES, OTHER_TRANSLATIONS
from production_report import ProductionReport
from PySide6.QtGui import QKeySequence, QFont, QShortcut, QPixmap
from datetime import date, datetime
import shutil
from PySide6.QtCore import Qt, QDate, QEvent, QPropertyAnimation, QEasingCurve, QTimer
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QFormLayout,QLabel,QLineEdit,QPushButton,QComboBox,QDateEdit,QDoubleSpinBox,QTableWidget,QTableWidgetItem,QTabWidget,QMessageBox,QDialog,QDialogButtonBox,QTextEdit,QFileDialog,QGroupBox,QHeaderView,QAbstractItemView,QCheckBox,QScrollArea,QInputDialog,QSpinBox,QSizePolicy,QToolButton,QRadioButton,QButtonGroup,QFrame,QSplitter,QGridLayout)

# Portable mode: data lives beside the EXE, not in Windows AppData.
# The same rule applies when running app.py during development.
APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
ROOT = APP_DIR / 'data'
try:
    ROOT.mkdir(parents=True, exist_ok=True)
except OSError:
    # User-writable fallback when installed in a protected directory.
    ROOT = Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / 'ALJABER_Concrete_2026' / 'data'
    ROOT.mkdir(parents=True, exist_ok=True)

db=sqlite3.connect(ROOT/'concrete.db')
db.execute('PRAGMA foreign_keys=ON')
db.executescript('''CREATE TABLE IF NOT EXISTS companies(id INTEGER PRIMARY KEY,name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS deliveries(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,day TEXT NOT NULL,details TEXT DEFAULT '',bem TEXT DEFAULT '',grade TEXT NOT NULL,qty REAL NOT NULL,unit_price REAL NOT NULL,notes TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(company_id) REFERENCES companies(id));
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,day TEXT NOT NULL,amount REAL NOT NULL,note TEXT DEFAULT '',FOREIGN KEY(company_id) REFERENCES companies(id));
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);''')
# Backward-compatible migration: existing portable databases keep all their records.
existing_columns={row[1] for row in db.execute('PRAGMA table_info(deliveries)')}
for column,definition in [('grade2',"TEXT DEFAULT ''"),('qty2','REAL DEFAULT 0'),('unit_price2','REAL DEFAULT 0')]:
    if column not in existing_columns:
        db.execute(f'ALTER TABLE deliveries ADD COLUMN {column} {definition}')
db.execute("""CREATE TABLE IF NOT EXISTS sites(id INTEGER PRIMARY KEY,company_id INTEGER NOT NULL,name TEXT NOT NULL,UNIQUE(company_id,name),FOREIGN KEY(company_id) REFERENCES companies(id))""")
for column,definition in [('site_id','INTEGER'),('site_name',"TEXT DEFAULT ''")]:
    if column not in existing_columns:db.execute(f'ALTER TABLE deliveries ADD COLUMN {column} {definition}')
db.commit()
def delivery_total(qty,price,qty2=0,price2=0):
    return float(qty or 0)*float(price or 0)+float(qty2 or 0)*float(price2 or 0)
def whatsapp_lines(qty,grade,qty2=0,grade2=''):
    result=[]
    if grade and float(qty or 0)>0:result.append(f'{float(qty):g}M - {grade}')
    if grade2 and float(qty2 or 0)>0:result.append(f'{float(qty2):g}M - {grade2}')
    return result
def expanded_deliveries(rows):
    # Export format retains its original eight-column delivery structure.
    expanded=[]
    for r in rows:
        if r[4] and float(r[5] or 0)>0:expanded.append(tuple(r[:8]))
        if len(r)>10 and r[8] and r[9]:
            expanded.append((r[0],r[1],r[2],r[3],r[8],r[9],r[10],r[7]))
    return expanded
def setting(k,default=''): 
    r=db.execute('SELECT value FROM settings WHERE key=?',(k,)).fetchone();return r[0] if r else default
def set_setting(k,v): db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(k,str(v)));db.commit()
def money(v):return f'{v:,.0f}'
def item(s):
    i=QTableWidgetItem(str(s));i.setTextAlignment(Qt.AlignCenter);return i

def xlsx_export(path,company,rows,pays):
    import xlsxwriter
    w=xlsxwriter.Workbook(path)
    s=w.add_worksheet('كشف الكونكريت')
    s.right_to_left();s.set_landscape();s.fit_to_pages(1,0);s.set_paper(9)
    s.set_margins(.28,.28,.42,.42);s.set_header('');s.set_footer('&CPage &P / &N')
    s.hide_gridlines(2);s.freeze_panes(6,0)
    widths=[7,17,23,17,12,16,18,20,20,18]
    for j,width in enumerate(widths):s.set_column(j,j,width)
    base={'font_name':'Arial','valign':'vcenter','align':'center'}
    def fmt(**kwargs):return w.add_format({**base,**kwargs})
    dark=fmt(bold=True,font_size=21,font_color='#FFFFFF',bg_color='#22272B')
    subtitle=fmt(bold=True,font_size=13,font_color='#F3A34B',bg_color='#22272B')
    info_label=fmt(bold=True,font_color='#5A6472',bg_color='#F0F2F5',border=1,border_color='#E0E4EA')
    info_value=fmt(bold=True,font_color='#22272B',bg_color='#F0F2F5',border=1,border_color='#E0E4EA')
    head=fmt(bold=True,font_color='#FFFFFF',bg_color='#D67B1F',border=1,border_color='#B86415',text_wrap=True)
    cells=[fmt(bg_color=('#FFFFFF' if i%2==0 else '#F3F5F8'),border=1,border_color='#E0E4EA') for i in range(2)]
    nums=[fmt(bg_color=('#FFFFFF' if i%2==0 else '#F3F5F8'),border=1,border_color='#E0E4EA',num_format='#,##0.##') for i in range(2)]
    sum_label=fmt(bold=True,font_color='#FFFFFF',bg_color='#343B43',border=1,border_color='#343B43')
    sum_num=fmt(bold=True,font_color='#FFFFFF',bg_color='#343B43',border=1,border_color='#343B43',num_format='#,##0.##')
    balance_label=fmt(bold=True,font_color='#22272B',bg_color='#F6D4AA',border=1,border_color='#D67B1F')
    balance_num=fmt(bold=True,font_color='#22272B',bg_color='#F6D4AA',border=1,border_color='#D67B1F',num_format='#,##0.##')
    s.merge_range('A1:J2','AL-JABER CONCRETE',dark)
    s.merge_range('A3:J3','كشف تجهيز الكونكريت  |  CONCRETE SUPPLY STATEMENT',subtitle)
    s.set_row(0,27);s.set_row(1,23);s.set_row(2,26)
    s.merge_range('A4:B4','الشركة / المقاول',info_label)
    s.merge_range('C4:G4',company,info_value)
    s.merge_range('H4:I4','تاريخ إصدار الكشف',info_label)
    s.write('J4',date.today().strftime('%d/%m/%Y'),info_value)
    s.set_row(3,26);s.set_row(4,9)
    headers=['ت','تاريخ التجهيز','التفاصيل','بم / سكرييد','النوعية','عدد الأمتار','سعر المتر','السعر الكلي','مبلغ التسديد','تاريخ التسديد']
    for j,h in enumerate(headers):s.write(5,j,h,head)
    s.set_row(5,35)
    n=max(len(rows),len(pays),1)
    for k in range(n):
        r=6+k;s.set_row(r,25)
        if k<len(rows):
            d=rows[k];values=[k+1,d[1],d[2],d[3],d[4],d[5],d[6]]
            for j,v in enumerate(values):
                if j in (5,6):s.write_number(r,j,float(v),nums[k%2])
                else:s.write(r,j,v,cells[k%2])
            s.write_formula(r,7,f'=F{r+1}*G{r+1}',nums[k%2],float(d[5]*d[6]))
        else:
            for j in range(8):s.write_blank(r,j,None,cells[k%2])
        if k<len(pays):
            s.write_number(r,8,float(pays[k][1]),nums[k%2]);s.write(r,9,pays[k][0],cells[k%2])
        else:
            s.write_blank(r,8,None,cells[k%2]);s.write_blank(r,9,None,cells[k%2])
    total_row=6+n
    s.merge_range(total_row,0,total_row,4,'الإجمالي',sum_label)
    s.write_formula(total_row,5,f'=SUM(F7:F{total_row})',sum_num,sum(x[5] for x in rows))
    s.write_blank(total_row,6,None,sum_num)
    total=sum(x[5]*x[6] for x in rows);paid=sum(x[1] for x in pays)
    s.write_formula(total_row,7,f'=SUM(H7:H{total_row})',sum_num,total)
    s.write_formula(total_row,8,f'=SUM(I7:I{total_row})',sum_num,paid)
    s.write_blank(total_row,9,None,sum_num)
    s.merge_range(total_row+1,0,total_row+1,7,'الرصيد المتبقي (دينار عراقي)',balance_label)
    s.write_formula(total_row+1,8,f'=H{total_row+1}-I{total_row+1}',balance_num,total-paid)
    s.write_blank(total_row+1,9,None,balance_num)
    s.set_row(total_row,30);s.set_row(total_row+1,32)
    s.repeat_rows(0,5);s.print_area(0,0,total_row+1,9)
    w.close()

def arabic(s):
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(str(s)))
    except ImportError:return str(s)
def pdf_export(path,company,rows,pays):
    from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
    from reportlab.lib import colors
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import A4,landscape
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    fonts=[r'C:\Windows\Fonts\arial.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf']
    f=next((p for p in fonts if Path(p).exists()),None)
    if not f:raise RuntimeError('لا يوجد خط عربي مناسب لإخراج PDF')
    pdfmetrics.registerFont(TTFont('ArabicUI',f))
    sty=ParagraphStyle('ar',fontName='ArabicUI',fontSize=8,leading=13,alignment=TA_CENTER)
    def p(x):return Paragraph(arabic(x),sty)
    headers=['ت','تاريخ التجهيز','التفاصيل','بم','النوعية','عدد الأمتار','سعر المتر','السعر الكلي','مبلغ التسديد','تاريخ التسديد']
    data=[[p(x) for x in headers]]
    for i in range(max(len(rows),len(pays),1)):
        if i<len(rows):
            r=rows[i];line=[i+1,r[1],r[2],r[3],r[4],f'{r[5]:g}',money(r[6]),money(r[5]*r[6])]
        else:line=['']*8
        line+=([money(pays[i][1]),pays[i][0]] if i<len(pays) else ['',''])
        data.append([p(x) for x in line])
    total=sum(r[5]*r[6] for r in rows);paid=sum(x[1] for x in pays)
    data.append([p(x) for x in ['الإجمالي','','','','',f'{sum(r[5] for r in rows):g}','',money(total),money(paid),money(total-paid)]])
    doc=SimpleDocTemplate(path,pagesize=landscape(A4),leftMargin=18,rightMargin=18,topMargin=20,bottomMargin=20)
    t=Table(data,colWidths=[25,85,105,40,45,57,70,80,80,85],repeatRows=1,rowHeights=None)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#D67B1F')),('BACKGROUND',(0,-1),(-1,-1),colors.HexColor('#F6D4AA')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('ROWBACKGROUNDS',(0,1),(-1,-2),[colors.white,colors.HexColor('#F3F5F8')]),('GRID',(0,0),(-1,-1),.5,colors.HexColor('#DCE1E8')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
    title=ParagraphStyle('title',fontName='ArabicUI',fontSize=19,leading=27,alignment=TA_CENTER)
    doc.build([Paragraph(arabic('AL-JABER CONCRETE'),title),Spacer(1,5),Paragraph(arabic('كشف تجهيز الكونكريت - '+company),title),Spacer(1,12),t])

# Message translations are shared by all screens and pop-up dialogs.
MESSAGE_TRANSLATIONS = {
    'تنبيه':'Warning', 'تأكيد':'Confirmation', 'تأكيد حذف تسديد':'Confirm Payment Deletion',
    'تم':'Success', 'خطأ التصدير':'Export Error', 'رسائل واتساب':'WhatsApp Messages',
    'الشركة موجودة مسبقاً':'This company already exists.',
    'هذا الاسم مستخدم':'This name is already in use.',
    'أضف شركة أولاً':'Please add a company first.',
    'اختر نوع كونكريت واحداً على الأقل.':'Please select a concrete grade.',
    'أدخل أمتار النوع الأول.':'Please enter the quantity for the first grade.',
    'أدخل أمتار النوع الثاني.':'Please enter the quantity for the second grade.',
    'تم نسخ الرسالة. يمكنك لصقها في الواتساب.':'Message copied. You can paste it into WhatsApp.',
    'تاريخ البداية يجب أن يسبق تاريخ النهاية.':'The start date must not be after the end date.',
    'لا توجد تجهيزات للشركات خلال الفترة المحددة.':'There are no deliveries for the selected period.',
    'تم حفظ النسخة الاحتياطية':'Backup saved successfully.',
    'حفظ نسخة احتياطية':'Save Backup', 'حفظ الكشف':'Save Report',
    'تم حفظ الكشف بنجاح:':'Report saved successfully:',
}
def translate_message(message,language):
    if language in (False,'العربية'):return message
    if language is True:language='English'
    if language!='English':
        if message in OTHER_TRANSLATIONS:
            return OTHER_TRANSLATIONS[message][{'Türkçe':0,'简体中文':1,'বাংলা':2,'اردو':3}[language]]
        if message.startswith('حذف ') and 'تجهيز محدد' in message:
            count=re.search(r'\\d+',message)
            n=count.group() if count else ''
            return {'Türkçe':f'{n} teslimat silinsin mi? Ödemeler silinmez.',
                    '简体中文':f'删除 {n} 条供货记录？付款记录不会删除。',
                    'বাংলা':f'{n}টি সরবরাহ মুছবেন? পেমেন্ট মুছবে না।',
                    'اردو':f'{n} سپلائیز حذف کریں؟ ادائیگیاں حذف نہیں ہوں گی۔'}[language]
        if message.startswith('هل تريد حذف ') and 'تسديد' in message:
            count=re.search(r'\\d+',message)
            n=count.group() if count else ''
            return {'Türkçe':f'{n} ödeme silinsin mi? Bu işlem bakiyeyi etkiler.',
                    '简体中文':f'删除 {n} 条付款记录？这会影响余额。',
                    'বাংলা':f'{n}টি পেমেন্ট মুছবেন? এতে ব্যালেন্স বদলাবে।',
                    'اردو':f'{n} ادائیگیاں حذف کریں؟ اس سے بقایا متاثر ہوگا۔'}[language]
        for original,translations in OTHER_TRANSLATIONS.items():
            if message.startswith(original):return translations[{'Türkçe':0,'简体中文':1,'বাংলা':2,'اردو':3}[language]]+message[len(original):]
        return message
    if message in MESSAGE_TRANSLATIONS:return MESSAGE_TRANSLATIONS[message]
    if message.startswith('حذف ') and 'تجهيز محدد' in message:
        count=re.search(r'\d+',message)
        return f'Delete {count.group() if count else "selected"} selected deliveries?\nPayments will not be deleted.'
    if message.startswith('هل تريد حذف ') and 'تسديد' in message:
        count=re.search(r'\d+',message)
        return f'Delete {count.group() if count else "selected"} payments? This will affect the financial balance.'
    for ar,en in MESSAGE_TRANSLATIONS.items():
        if message.startswith(ar):return en+message[len(ar):]
    return message

class App(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle('AL-JABER Concrete 2026 | تجهيز الكونكريت');self.resize(1320,820)
        self.central=QWidget();self.central_layout=QVBoxLayout(self.central)
        self.central_layout.setContentsMargins(0,0,0,0)
        self.layout_banner=QFrame();self.layout_banner.setObjectName('layoutBanner')
        banner_layout=QHBoxLayout(self.layout_banner)
        self.logo=QLabel()
        logo_path=APP_DIR/'aljaber_logo.png'
        if logo_path.exists():
            pix=QPixmap(str(logo_path))
            if not pix.isNull():self.logo.setPixmap(pix.scaled(85,55,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        banner_layout.addWidget(self.logo)
        self.brand_title=QLabel('شركة الجابر  |  AL-JABER CONCRETE 2026')
        self.brand_title.setAlignment(Qt.AlignCenter)
        self.brand_title.setObjectName('brandTitle')
        banner_layout.addWidget(self.brand_title)
        self.metric_companies=QLabel();self.metric_loads=QLabel();self.metric_balance=QLabel()
        for metric in (self.metric_companies,self.metric_loads,self.metric_balance):
            metric.setObjectName('metricCard');banner_layout.addWidget(metric)
        self.central_layout.addWidget(self.layout_banner)
        self.tabs=QTabWidget();self.central_layout.addWidget(self.tabs,1)
        self.setCentralWidget(self.central)
        self.company_tab=QWidget();self.load_tab=QWidget();self.pay_tab=QWidget();self.export_tab=QWidget();self.whatsapp_tab=QWidget();self.settings_tab=QWidget();self.company_pages=QTabWidget();self.company_pages.setTabsClosable(False);self.company_pages.setMovable(True);self.company_pages.setUsesScrollButtons(True)
        for t,n in [(self.company_tab,'الشركات'),(self.load_tab,'التجهيزات'),(self.pay_tab,'التسديدات'),(self.export_tab,'الكشوفات'),(self.settings_tab,'الإعدادات')]:self.tabs.addTab(t,n)
        self.tabs.insertTab(self.tabs.count()-1,self.company_pages,'كشوف الشركات')
        self.tabs.insertTab(self.tabs.count()-1,self.whatsapp_tab,'رسائل واتساب')
        self.make_companies();self.make_loads();self.make_payments();self.make_export();self.make_whatsapp_tab();self.make_settings()
        self.production_tab=ProductionReport(db,setting,set_setting,self)
        self.tabs.insertTab(self.tabs.count()-1,self.production_tab,'Production Report')
        self.refresh_companies();self.apply_theme();self.apply_language();self.setup_shortcuts()
        QApplication.instance().installEventFilter(self)
        self.apply_layout_design()
    def change_layout_design(self,index):
        if index<0:return
        set_setting('layout_design',self.layout_picker.itemData(index))
        self.apply_layout_design()
    def apply_layout_design(self):
        mode=setting('layout_design','industrial')
        positions={key:QTabWidget.North for key in ('modern','erp','glass','minimal','industrial')}
        self.tabs.setTabPosition(positions.get(mode,QTabWidget.North))
        self.tabs.setDocumentMode(mode in ('minimal','glass'))
        self.layout_banner.setVisible(mode!='minimal')
        self.central_layout.setSpacing({'modern':12,'erp':6,'glass':16,'minimal':2,'industrial':8}.get(mode,8))
        self.central_layout.setContentsMargins(*({'modern':(12,10,12,10),'erp':(6,6,6,6),
           'glass':(18,14,18,14),'minimal':(2,2,2,2),'industrial':(10,10,10,10)}.get(mode,(8,8,8,8))))
        self.brand_title.setText({
            'modern':'AL-JABER  /  Dashboard','erp':'AL-JABER  /  ERP',
            'glass':'AL-JABER  /  Glass Workspace','minimal':'AL-JABER',
            'industrial':'AL-JABER  /  INDUSTRIAL CONTROL'
        }.get(mode,'AL-JABER'))
        self.refresh_layout_metrics()
        if hasattr(self,'load_grid'):self.apply_load_grid()
        self.apply_theme()
    def change_load_columns(self,index):
        if index<0:return
        set_setting('load_columns',str(self.load_columns_picker.itemData(index)))
        self.apply_load_grid()
    def apply_load_grid(self,*_):
        if not hasattr(self,'secondary_widgets'):return
        second=self.secondary_toggle.isChecked();price=self.price_toggle.isChecked()
        for w,label in zip(self.secondary_widgets,self.secondary_labels):w.setVisible(second);label.setVisible(second)
        for i,(w,label) in enumerate(zip(self.price_widgets,self.price_labels)):
            visible=price and (i==0 or second)
            w.setVisible(visible);label.setVisible(visible)
        self.l_grade2.setEnabled(second);self.l_qty2.setEnabled(second);self.l_price2.setEnabled(second and price)
    def apply_load_grid_legacy(self):pass
    def refresh_layout_metrics(self):
        try:
            companies=db.execute('SELECT COUNT(*) FROM companies').fetchone()[0]
            deliveries=db.execute('SELECT COUNT(*) FROM deliveries').fetchone()[0]
            total=db.execute('SELECT COALESCE(SUM(qty*unit_price+COALESCE(qty2,0)*COALESCE(unit_price2,0)),0) FROM deliveries').fetchone()[0]
            paid=db.execute('SELECT COALESCE(SUM(amount),0) FROM payments').fetchone()[0]
            self.metric_companies.setText(f'🏢  {companies}  شركات')
            self.metric_loads.setText(f'🚚  {deliveries}  تجهيزات')
            self.metric_balance.setText(f'💰  {money(total-paid)} IQD')
        except Exception:pass
    def show_about(self):
        lang=setting('language','العربية')
        titles={'العربية':'حول البرنامج','English':'About','Türkçe':'Hakkında','简体中文':'关于',
                'বাংলা':'সম্পর্কে','اردو':'پروگرام کے بارے میں'}
        description={
            'العربية':'برنامج لإدارة تجهيزات الكونكريت للشركات والكميات والأسعار والتسديدات والأرصدة، مع تصدير Excel وPDF ورسائل واتساب.',
            'English':'Manage concrete deliveries, companies, quantities, prices, payments and balances, with Excel/PDF exports and WhatsApp messages.',
            'Türkçe':'Beton teslimatları, şirketler, miktarlar, fiyatlar, ödemeler ve bakiyeler; Excel/PDF ve WhatsApp.',
            '简体中文':'管理混凝土供货、公司、数量、价格、付款及余额，并支持 Excel/PDF 导出和 WhatsApp 消息。',
            'বাংলা':'কংক্রিট সরবরাহ, কোম্পানি, পরিমাণ, মূল্য, পেমেন্ট ও ব্যালেন্স ব্যবস্থাপনা; Excel/PDF ও WhatsApp।',
            'اردو':'کنکریٹ سپلائی، کمپنیوں، مقدار، قیمت، ادائیگی اور بقایا کا انتظام؛ Excel/PDF اور واٹس ایپ۔'}
        dialog=QDialog(self)
        dialog.setWindowTitle(titles.get(lang,'About'))
        dialog.resize(500,350)
        v=QVBoxLayout(dialog)
        heading=QLabel('AL-JABER Concrete 2026');heading.setAlignment(Qt.AlignCenter)
        heading.setStyleSheet('font-size:22px;font-weight:700;')
        v.addWidget(heading)
        desc=QLabel(description.get(lang,description['English']))
        desc.setWordWrap(True);desc.setAlignment(Qt.AlignCenter);v.addWidget(desc)
        credit=QLabel('Developed by / تطوير\\nABUHMED1991\\n© 2026 ABUHMED1991')
        credit.setAlignment(Qt.AlignCenter)
        credit.setStyleSheet('font-size:16px;font-weight:700;padding:15px;')
        v.addWidget(credit)
        v.addWidget(QLabel('Version 2026.11  •  Windows Desktop  •  6 Languages'))
        v.addWidget(self.button('إغلاق | Close',dialog.accept))
        dialog.exec()
    def setup_shortcuts(self):
        self._shortcuts=[]
        def bind(sequence,callback,widget=None):
            sc=QShortcut(QKeySequence(sequence),widget or self)
            sc.setContext(Qt.WidgetWithChildrenShortcut)
            sc.activated.connect(callback);self._shortcuts.append(sc)
        bind('Ctrl+S',self.save_load)
        bind('Alt+N',lambda:(self.tabs.setCurrentWidget(self.company_tab),self.company_name.setFocus()))
        bind('Alt+E',lambda:self.export('xlsx'))
        bind('Alt+P',lambda:self.export('pdf'))
        for table,delete_func in ((self.l_table,self.delete_load),(self.p_table,self.delete_payment)):
            bind('Delete',delete_func,table)
            bind('Ctrl+Delete',delete_func,table)
            bind('Ctrl+A',table.selectAll,table)
            bind('Escape',table.clearSelection,table)
            bind('Ctrl+C',lambda t=table:self.copy_table_selection(t),table)
    def copy_table_selection(self,table):
        cells=table.selectedIndexes()
        if not cells:return
        data={}
        for index in cells:data.setdefault(index.row(),{})[index.column()]=index.data() or ''
        cols=sorted({c for row in data.values() for c in row})
        QApplication.clipboard().setText('\\n'.join('\\t'.join(str(data[r].get(c,'')) for c in cols) for r in sorted(data)))
    def apply_navigation_style(self):
        style=setting('nav_style','minimal')
        names={'الشركات':('Companies','🏢'),'التجهيزات':('Deliveries','🚚'),'التسديدات':('Payments','💳'),
               'الكشوفات':('Reports','📊'),'كشوف الشركات':('Company Tabs','📁'),
               'رسائل واتساب':('WhatsApp','💬'),'Production Report':('Production Report','🏭'),
               'الإعدادات':('Settings','⚙️')}
        for i in range(self.tabs.count()):
            tab=self.tabs.widget(i)
            key=('Production Report' if tab is getattr(self,'production_tab',None) else
                 'الشركات' if tab is self.company_tab else
                 'التجهيزات' if tab is self.load_tab else
                 'التسديدات' if tab is self.pay_tab else
                 'الكشوفات' if tab is self.export_tab else
                 'كشوف الشركات' if tab is self.company_pages else
                 'رسائل واتساب' if tab is self.whatsapp_tab else 'الإعدادات')
            en,emoji=names[key]
            title=en if setting('language','العربية')=='English' else key
            if style=='emoji':title=emoji+' '+title
            elif style=='technical':title=f'{i+1:02d} • '+en.upper()
            elif style=='short':title=f'[{i+1}]'
            self.tabs.setTabText(i,title)
    def apply_density(self):
        density=setting('density','medium')
        rowheight={'small':25,'medium':33,'large':44}.get(density,33)
        for t in self.findChildren(QTableWidget):
            t.verticalHeader().setDefaultSectionSize(rowheight)
        self.apply_theme()
    def reset_appearance(self):
        for key,value in [('theme','هوية الجابر'),('font','Segoe UI'),('font_size','12'),('scale','100'),('density','medium'),('nav_style','minimal'),('layout_design','industrial')]:
            set_setting(key,value)
        self.theme.setCurrentIndex(self.theme.findData('هوية الجابر'))
        self.font_picker.setCurrentText('Segoe UI');self.font_size.setValue(12)
        self.scale.setValue(100);self.density.setCurrentIndex(self.density.findData('medium'))
        self.nav_style.setCurrentIndex(self.nav_style.findData('minimal'))
        self.layout_picker.setCurrentIndex(self.layout_picker.findData('industrial'))
        self.apply_density();self.apply_navigation_style()
    def translate_dialog(self,dialog):
        lang=setting('language','العربية')
        en=lang=='English'
        labels={
            'اختر تاريخ التجهيز ثم حدد الأسطر التي تريد تضمينها في الرسالة':'Select a delivery date and the rows to include in the message',
            'تحديث الرسالة':'Refresh Message', 'نسخ رسالة الواتساب':'Copy WhatsApp Message',
            'نسخ رسالة هذه الشركة':'Copy This Company Message','إغلاق':'Close',
            'الكمية م³':'Quantity (m³)','الأمتار 2':'Quantity 2','النوعية 2':'Grade 2','الملاحظات':'Notes',
            'رقم':'ID','التاريخ':'Date','النوعية':'Grade','بم':'Pump / Screed','التفاصيل':'Details',
            'ستظهر رسالة الواتساب هنا ويمكنك تعديلها قبل النسخ':'WhatsApp message preview (editable)',
        }
        for w in dialog.findChildren(QWidget):
            if isinstance(w,(QLabel,QPushButton)):
                old=w.text();w.setText((labels.get(old,old) if en else translate_message(old,lang)))
            elif isinstance(w,QTextEdit):
                old=w.placeholderText();w.setPlaceholderText((labels.get(old,old) if en else translate_message(old,lang)))
            elif isinstance(w,QTableWidget):
                for j in range(w.columnCount()):
                    header=w.horizontalHeaderItem(j)
                    if header:header.setText((labels.get(header.text(),header.text()) if en else translate_message(header.text(),lang)))

    def message(self,kind,parent,title,body):
        lang=setting('language','العربية')
        title=translate_message(title,lang);body=translate_message(body,lang)
        if kind=='question':
            box=QMessageBox(parent);box.setIcon(QMessageBox.Question)
            box.setWindowTitle(title);box.setText(body)
            box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            box.button(QMessageBox.Yes).setText('Yes' if lang=='English' else translate_message('نعم',lang))
            box.button(QMessageBox.No).setText('No' if lang=='English' else translate_message('لا',lang))
            return box.exec()
        return getattr(QMessageBox,kind)(parent,title,body)

    def sync_secondary_grade(self):
        enabled=bool(self.l_grade2.currentText().strip())
        self.l_qty2.setEnabled(enabled)
        self.l_price2.setEnabled(enabled)
        if not enabled:
            self.l_qty2.setValue(0)
            self.l_price2.setValue(0)
        self.update_total()

    def button(self,text,func):
        b=QPushButton(text)
        b.setSizePolicy(QSizePolicy.Maximum,QSizePolicy.Fixed)
        b.clicked.connect(func)
        b.setMinimumHeight(27)
        b.setMaximumHeight(34)
        b.setSizePolicy(QSizePolicy.Maximum,QSizePolicy.Fixed)
        b.setCursor(Qt.PointingHandCursor)
        return b
    def layout(self,w):
        l=QVBoxLayout(w);l.setSpacing(12);l.setContentsMargins(20,18,20,18);return l
    def company_combo(self):return QComboBox()
    def refresh_companies(self):
        companies=db.execute('SELECT id,name FROM companies ORDER BY name').fetchall()
        for cb in [self.c_company,self.l_company,self.p_company,self.e_company]+([self.w_company] if hasattr(self,'w_company') else []):
            old=cb.currentData();cb.blockSignals(True);cb.clear()
            if cb is self.e_company or (hasattr(self,'w_company') and cb is self.w_company):cb.addItem('ALL – جميع الشركات',None)
            for id,name in companies:cb.addItem(name,id)
            ix=cb.findData(old)
            if ix>=0:cb.setCurrentIndex(ix)
            cb.blockSignals(False)
        self.refresh_all();self.refresh_company_pages();self.refresh_export_preview();self.refresh_whatsapp_inline()
        if hasattr(self,'l_site'):self.refresh_load_sites()
        if hasattr(self,'site_company'):self.refresh_site_management()
    def make_companies(self):
        l=self.layout(self.company_tab);l.addWidget(QLabel('إضافة شركة / مقاول جديد'))
        row=QHBoxLayout();self.company_name=QLineEdit();self.company_name.setPlaceholderText('اسم الشركة');self.company_name.returnPressed.connect(self.add_company);row.addWidget(self.company_name);row.addWidget(self.button('إضافة شركة',self.add_company));l.addLayout(row)
        self.c_company=self.company_combo();row=QHBoxLayout();row.addWidget(self.c_company);row.addWidget(self.button('تعديل الاسم',self.rename_company));l.addLayout(row)
        l.addWidget(QLabel('كل شركة لها كشف مستقل، ويمكن اختيارها من الصفحات الأخرى.'))
        sites=QGroupBox('المواقع الخاصة بكل شركة');sv=QVBoxLayout(sites)
        self.site_company=self.company_combo();sv.addWidget(self.site_company)
        sr=QHBoxLayout();self.site_name=QLineEdit();self.site_name.setPlaceholderText('اسم الموقع الجديد');sr.addWidget(self.site_name)
        sr.addWidget(self.button('إضافة موقع',self.add_site));sv.addLayout(sr)
        self.site_list=QComboBox();sv.addWidget(self.site_list)
        actions=QHBoxLayout();actions.addWidget(self.button('تعديل الموقع',self.rename_site));actions.addWidget(self.button('حذف الموقع',self.delete_site));sv.addLayout(actions)
        self.site_company.currentIndexChanged.connect(self.refresh_site_management)
        l.addWidget(sites);l.addStretch()
    def refresh_site_management(self,*_):
        if not hasattr(self,'site_company'):return
        old=self.site_company.currentData()
        companies=db.execute('SELECT id,name FROM companies ORDER BY name').fetchall()
        self.site_company.blockSignals(True);self.site_company.clear()
        for cid,name in companies:self.site_company.addItem(name,cid)
        idx=self.site_company.findData(old)
        if idx>=0:self.site_company.setCurrentIndex(idx)
        self.site_company.blockSignals(False)
        self.site_list.clear()
        cid=self.site_company.currentData()
        if cid:
            for sid,name in db.execute('SELECT id,name FROM sites WHERE company_id=? ORDER BY name',(cid,)):
                self.site_list.addItem(name,sid)
    def add_site(self):
        cid=self.site_company.currentData();name=self.site_name.text().strip()
        if not cid or not name:return
        try:db.execute('INSERT INTO sites(company_id,name) VALUES(?,?)',(cid,name));db.commit()
        except sqlite3.IntegrityError:return self.message('warning',self,'تنبيه','الموقع موجود مسبقاً لهذه الشركة')
        self.site_name.clear();self.refresh_site_management();self.refresh_load_sites()
    def rename_site(self):
        sid=self.site_list.currentData()
        if not sid:return
        name,ok=QInputDialog.getText(self,'تعديل الموقع','اسم الموقع الجديد:',text=self.site_list.currentText())
        if not ok or not name.strip():return
        try:db.execute('UPDATE sites SET name=? WHERE id=?',(name.strip(),sid));db.commit()
        except sqlite3.IntegrityError:return self.message('warning',self,'تنبيه','الموقع موجود مسبقاً')
        self.refresh_site_management();self.refresh_load_sites()
    def delete_site(self):
        sid=self.site_list.currentData()
        if not sid:return
        if self.message('question',self,'تأكيد','حذف الموقع من القائمة؟ ستبقى أسماء المواقع في التجهيزات القديمة.')!=QMessageBox.Yes:return
        db.execute('UPDATE deliveries SET site_id=NULL WHERE site_id=?',(sid,))
        db.execute('DELETE FROM sites WHERE id=?',(sid,));db.commit()
        self.refresh_site_management();self.refresh_load_sites()
    def refresh_load_sites(self,*_):
        if not hasattr(self,'l_site'):return
        cid=self.l_company.currentData();old=self.l_site.currentData()
        self.l_site.blockSignals(True);self.l_site.clear();self.l_site.addItem('بدون موقع',None)
        if cid:
            for sid,name in db.execute('SELECT id,name FROM sites WHERE company_id=? ORDER BY name',(cid,)):
                self.l_site.addItem(name,sid)
        ix=self.l_site.findData(old)
        self.l_site.setCurrentIndex(ix if ix>=0 else 0);self.l_site.blockSignals(False)
    def add_company(self):
        n=self.company_name.text().strip()
        if not n:return
        try:db.execute('INSERT INTO companies(name) VALUES(?)',(n,));db.commit();self.company_name.clear();self.refresh_companies()
        except sqlite3.IntegrityError:self.message('warning',self,'تنبيه','الشركة موجودة مسبقاً')
    def rename_company(self):
        id=self.c_company.currentData();n=self.company_name.text().strip()
        if not id or not n:return
        try:db.execute('UPDATE companies SET name=? WHERE id=?',(n,id));db.commit();self.company_name.clear();self.refresh_companies()
        except sqlite3.IntegrityError:self.message('warning',self,'تنبيه','هذا الاسم مستخدم')
    def datefield(self):
        x=QDateEdit(QDate.currentDate());x.setCalendarPopup(True);x.setDisplayFormat('dd/MM/yyyy');return x
    def make_loads(self):
        l=self.layout(self.load_tab)
        date_row=QHBoxLayout();date_row.addWidget(QLabel('تاريخ التجهيز'))
        self.l_date=self.datefield();date_row.addWidget(self.l_date);date_row.addStretch();l.addLayout(date_row)
        main=QHBoxLayout();main.setSpacing(8)
        concrete=QGroupBox('بيانات الكونكريت');cg=QFormLayout(concrete);cg.setSpacing(4)
        company=QGroupBox('بيانات الشركة');co=QFormLayout(company);co.setSpacing(4)
        self.l_company=self.company_combo();self.l_site=self.company_combo();self.l_details=QLineEdit();self.l_note=QLineEdit()
        co.addRow('الشركة',self.l_company);co.addRow('الموقع',self.l_site);co.addRow('التفاصيل',self.l_details)
        self.note_toggle=QCheckBox('إضافة ملاحظات');co.addRow(self.note_toggle);co.addRow('الملاحظات',self.l_note)
        self.note_label=co.labelForField(self.l_note)
        self.note_toggle.toggled.connect(lambda checked:(self.l_note.setVisible(checked),self.note_label.setVisible(checked)))
        self.l_note.hide();self.note_label.hide()
        self.l_bem=QComboBox();self.l_bem.setEditable(True);self.l_bem.addItems(['','Pump - بم'])
        self.l_grade=QComboBox();self.l_grade.addItems(['']+[f'C{x}' for x in (15,20,25,30,35,40)]+['Screed - سكرييد'])
        self.l_qty=QDoubleSpinBox();self.l_qty.setRange(0,100000);self.l_qty.setDecimals(2)
        self.l_price=QDoubleSpinBox();self.l_price.setRange(0,1e10);self.l_price.setDecimals(0);self.l_price.setSingleStep(5000)
        self.l_grade2=QComboBox();self.l_grade2.addItems(['']+[f'C{x}' for x in (15,20,25,30,35,40)]+['Screed - سكرييد'])
        self.l_qty2=QDoubleSpinBox();self.l_qty2.setRange(0,100000);self.l_qty2.setDecimals(2)
        self.l_price2=QDoubleSpinBox();self.l_price2.setRange(0,1e10);self.l_price2.setDecimals(0);self.l_price2.setSingleStep(5000)
        self.l_total=QLabel('0 د.ع');self.l_qty.valueChanged.connect(self.update_total);self.l_price.valueChanged.connect(self.update_total)
        self.l_qty2.valueChanged.connect(self.update_total);self.l_price2.valueChanged.connect(self.update_total)
        cg.addRow('نوع الكونكريت',self.l_grade);cg.addRow('عدد الأمتار',self.l_qty);cg.addRow('البم',self.l_bem)
        self.secondary_toggle=QCheckBox('إضافة نوع كونكريت ثانٍ');cg.addRow(self.secondary_toggle)
        cg.addRow('نوع الكونكريت الثاني',self.l_grade2);cg.addRow('الأمتار الثانية',self.l_qty2)
        self.price_toggle=QCheckBox('إظهار سعر المتر');cg.addRow(self.price_toggle)
        cg.addRow('سعر المتر الأول',self.l_price);cg.addRow('سعر المتر الثاني',self.l_price2)
        cg.addRow('السعر الكلي',self.l_total)
        self.secondary_widgets=[self.l_grade2,self.l_qty2]
        self.secondary_labels=[cg.labelForField(w) for w in self.secondary_widgets]
        self.price_widgets=[self.l_price,self.l_price2]
        self.price_labels=[cg.labelForField(w) for w in self.price_widgets]
        self.secondary_toggle.toggled.connect(self.apply_load_grid);self.price_toggle.toggled.connect(self.apply_load_grid)
        self.l_grade2.currentTextChanged.connect(self.sync_secondary_grade)
        main.addWidget(company,1);main.addWidget(concrete,1);l.addLayout(main)
        self.apply_load_grid()
        row=QHBoxLayout();row.addWidget(self.button('إدراج التجهيز',self.save_load));row.addWidget(self.button('تعديل المحدد',self.edit_load));row.addWidget(self.button('حذف المحدد',self.delete_load));row.addStretch();l.addLayout(row)
        self.l_table=self.table(['رقم','الشركة','التاريخ','الموقع','التفاصيل','بم','النوعية','الأمتار','سعر المتر','الإجمالي','ملاحظات'])
        self.l_table.itemSelectionChanged.connect(self.load_selected);l.addWidget(self.l_table,1)
        self.editing=None;self._load_previous_company=self.l_company.currentData();self._suppress_company_reset=False
        self.l_company.currentIndexChanged.connect(self.company_changed_on_loads)
        self.refresh_load_sites()
    def reset_load_fields(self):
        self.l_date.setDate(QDate.currentDate())
        self.l_details.clear();self.l_site.setCurrentIndex(0);self.l_bem.setCurrentIndex(0)
        self.l_grade.setCurrentIndex(0);self.l_qty.setValue(0);self.l_price.setValue(0)
        self.l_grade2.setCurrentIndex(0);self.l_qty2.setValue(0);self.l_price2.setValue(0)
        self.secondary_toggle.setChecked(False);self.price_toggle.setChecked(False);self.note_toggle.setChecked(False)
        self.l_note.clear();self.editing=None
        self.update_total()
    def load_form_has_data(self):
        return bool(self.editing or self.l_details.text().strip() or self.l_note.text().strip()
                    or self.l_bem.currentText().strip() or self.l_grade.currentText()
                    or self.l_qty.value() or self.l_price.value() or self.l_grade2.currentText()
                    or self.l_qty2.value() or self.l_price2.value())
    def company_changed_on_loads(self,*_):
        new=self.l_company.currentData()
        if getattr(self,'_suppress_company_reset',False):return
        old=getattr(self,'_load_previous_company',None)
        if old==new:return
        if self.load_form_has_data():
            answer=self.message('question',self,'تأكيد تغيير الشركة',
                'تغيير الشركة سيمسح بيانات التجهيز غير المحفوظة. هل تريد المتابعة؟')
            if answer!=QMessageBox.Yes:
                self.l_company.blockSignals(True)
                self.l_company.setCurrentIndex(self.l_company.findData(old))
                self.l_company.blockSignals(False)
                return
        self._load_previous_company=new
        self.refresh_load_sites();self.reset_load_fields()
    def update_total(self):self.l_total.setText(money(delivery_total(self.l_qty.value(),self.l_price.value(),self.l_qty2.value() if self.l_grade2.currentText() else 0,self.l_price2.value()))+' د.ع')
    def table(self,headers):
        t=QTableWidget(0,len(headers));t.setHorizontalHeaderLabels(headers);t.setSelectionBehavior(QAbstractItemView.SelectRows);t.setSelectionMode(QAbstractItemView.ExtendedSelection);t.setEditTriggers(QAbstractItemView.NoEditTriggers);t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);t.verticalHeader().hide();return t
    def save_load(self):
        cid=self.l_company.currentData()
        if not cid:return self.message('warning',self,'تنبيه','أضف شركة أولاً')
        grade=self.l_grade.currentText().strip()
        grade2=self.l_grade2.currentText().strip()
        if not grade:
            return self.message('warning',self,'تنبيه','اختر نوع كونكريت واحداً على الأقل.')
        if grade and self.l_qty.value()<=0:
            return self.message('warning',self,'تنبيه','أدخل أمتار النوع الأول.')
        if grade2 and self.l_qty2.value()<=0:
            return self.message('warning',self,'تنبيه','أدخل أمتار النوع الثاني.')
        site_id=self.l_site.currentData()
        site_name=''
        if site_id is not None:
            valid=db.execute('SELECT name FROM sites WHERE id=? AND company_id=?',(site_id,cid)).fetchone()
            if not valid:return self.message('warning',self,'تنبيه','الموقع غير تابع للشركة المختارة')
            site_name=valid[0]
        vals=(cid,self.l_date.date().toString('yyyy-MM-dd'),self.l_details.text(),
              self.l_bem.currentText(),grade,self.l_qty.value() if grade else 0,
              self.l_price.value() if grade else 0,self.l_note.text(),
              grade2,self.l_qty2.value() if grade2 else 0,self.l_price2.value() if grade2 else 0,site_id,site_name)
        if self.editing:
            db.execute("""UPDATE deliveries SET company_id=?,day=?,details=?,bem=?,grade=?,qty=?,
                unit_price=?,notes=?,grade2=?,qty2=?,unit_price2=?,site_id=?,site_name=? WHERE id=?""",(*vals,self.editing))
        else:
            db.execute("""INSERT INTO deliveries(company_id,day,details,bem,grade,qty,unit_price,notes,grade2,qty2,unit_price2,site_id,site_name)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",vals)
        db.commit()
        self.editing=None
        # Reset the input form only after the database commit succeeded.
        # Preserve the selected company for consecutive deliveries.
        self.reset_load_fields()
        self.refresh_all()
        # Keep WhatsApp company/load selectors in sync with every new delivery.
        self.refresh_whatsapp_inline()
    def load_selected(self):
        pass
    def edit_load(self):
        row=self.l_table.currentRow()
        if row<0:return
        id=int(self.l_table.item(row,0).text());r=db.execute('SELECT company_id,day,details,bem,grade,qty,unit_price,notes,grade2,qty2,unit_price2,site_id,site_name FROM deliveries WHERE id=?',(id,)).fetchone()
        if not r:return
        self._suppress_company_reset=True
        self.l_company.setCurrentIndex(self.l_company.findData(r[0]))
        self._suppress_company_reset=False
        self._load_previous_company=r[0]
        self.refresh_load_sites()
        site_index=self.l_site.findData(r[11]);self.l_site.setCurrentIndex(site_index if site_index>=0 else 0)
        self.note_toggle.setChecked(bool(r[7]));self.price_toggle.setChecked(bool(r[6] or r[10]))
        self.editing=id;self.l_date.setDate(QDate.fromString(r[1],'yyyy-MM-dd'));self.l_details.setText(r[2]);self.l_bem.setCurrentText('' if 'Screed' in (r[3] or '') or 'سكرييد' in (r[3] or '') else (r[3] or ''));self.l_grade.setCurrentText('Screed - سكرييد' if ('Screed' in (r[3] or '') or 'سكرييد' in (r[3] or '')) and not (r[4] or '').strip() else r[4]);self.l_qty.setValue(r[5]);self.l_price.setValue(r[6]);self.l_note.setText(r[7]);self.l_grade2.setCurrentText(r[8] or '');self.l_qty2.setValue(r[9] or 0);self.l_price2.setValue(r[10] or 0);self.secondary_toggle.setChecked(bool(r[8]));self.tabs.setCurrentWidget(self.load_tab)
    def delete_load(self):
        ids=[int(self.l_table.item(i.row(),0).text()) for i in self.l_table.selectionModel().selectedRows()]
        if not ids:return
        if self.message('question',self,'تأكيد',f'حذف {len(ids)} تجهيز محدد؟\nلن تُحذف التسديدات.')!=QMessageBox.Yes:return
        db.executemany('DELETE FROM deliveries WHERE id=?',[(x,) for x in ids]);db.commit();self.editing=None;self.refresh_all()
    def create_whatsapp(self,company_id=None):
        if company_id is None: company_id=self.l_company.currentData()
        if not company_id:return self.message('warning',self,'تنبيه','أضف شركة أولاً')
        name=db.execute('SELECT name FROM companies WHERE id=?',(company_id,)).fetchone()[0]
        dlg=QDialog(self);dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowMinMaxButtonsHint);dlg.setWindowTitle('WhatsApp | رسالة التجهيز');dlg.resize(720,600)
        v=QVBoxLayout(dlg);v.addWidget(QLabel('اختر تاريخ التجهيز ثم حدد الأسطر التي تريد تضمينها في الرسالة'))
        day=self.datefield();v.addWidget(day)
        table=self.table(['رقم','التاريخ','الكمية م³','النوعية','بم','التفاصيل','الأمتار 2','النوعية 2','الملاحظات'])
        table.setSelectionMode(QAbstractItemView.MultiSelection);v.addWidget(table)
        preview=QTextEdit();preview.setPlaceholderText('ستظهر رسالة الواتساب هنا ويمكنك تعديلها قبل النسخ');v.addWidget(preview)
        def fill():
            rows=db.execute('SELECT id,day,qty,grade,bem,details,qty2,grade2,notes FROM deliveries WHERE company_id=? AND day=? ORDER BY id',(company_id,day.date().toString('yyyy-MM-dd'))).fetchall()
            table.setRowCount(len(rows))
            for i,r in enumerate(rows):
                for j,x in enumerate((r[0],*r[1:])):table.setItem(i,j,item(x))
            table.selectAll();generate()
        def generate():
            chosen=sorted({i.row() for i in table.selectionModel().selectedRows()})
            lines=[name];remarks=[]
            for i in chosen:
                if not table.item(i,2):continue
                qty=table.item(i,2).text();grade=table.item(i,3).text()
                bem=table.item(i,4).text().strip()
                lines.extend(whatsapp_lines(qty,grade,table.item(i,6).text(),table.item(i,7).text()))
                note=table.item(i,8).text().strip() if table.item(i,8) else ''
                if note and note not in remarks:remarks.append(note)
                if bem:
                    marker='Pump' if 'Pump' in bem else ('Screed' if 'Screed' in bem else bem)
                    if marker not in remarks:remarks.append(marker)
            lines.extend(remarks)
            lines.append(day.date().toString('yyyy/MM/dd'))
            preview.setPlainText('\n'.join(lines))
        def copy():
            QApplication.clipboard().setText(preview.toPlainText());self.message('information',dlg,'WhatsApp','تم نسخ الرسالة. يمكنك لصقها في الواتساب.')
        day.dateChanged.connect(fill);table.itemSelectionChanged.connect(generate)
        row=QHBoxLayout();row.addWidget(self.button('تحديث الرسالة',generate));row.addWidget(self.button('نسخ رسالة الواتساب',copy))
        v.addLayout(row)
        day.setDate(self.l_date.date());fill();self.translate_dialog(dlg);dlg.exec()

    def create_all_companies_whatsapp(self):
        """One editable, individually copyable message per company in the selected report period."""
        start=self.e_start.date().toString('yyyy-MM-dd')
        end=self.e_end.date().toString('yyyy-MM-dd')
        if start>end:
            return self.message('warning',self,'تنبيه','تاريخ البداية يجب أن يسبق تاريخ النهاية.')
        records=db.execute("""SELECT c.id,c.name,d.day,d.qty,d.grade,d.bem,d.qty2,d.grade2,d.notes
                              FROM deliveries AS d JOIN companies AS c ON c.id=d.company_id
                              WHERE d.day BETWEEN ? AND ?
                              ORDER BY c.name COLLATE NOCASE,d.day,d.id""",(start,end)).fetchall()
        if not records:
            return self.message('information',self,'رسائل واتساب','لا توجد تجهيزات للشركات خلال الفترة المحددة.')
        grouped={}
        for cid,name,day,qty,grade,bem,qty2,grade2,note in records:
            grouped.setdefault(cid,{'name':name,'days':{}})['days'].setdefault(day,[]).append((qty,grade,bem,qty2,grade2,note))
        dlg=QDialog(self)
        dlg.setWindowFlags(dlg.windowFlags() | Qt.WindowMinMaxButtonsHint)
        dlg.setWindowTitle(translate_message('رسائل واتساب',setting('language','العربية'))+' | WhatsApp by Company')
        dlg.resize(760,680)
        outer=QVBoxLayout(dlg)
        outer.addWidget(QLabel(translate_message('رسالة مستقلة لكل شركة حسب تاريخ تجهيزاتها الفعلي. يمكنك تعديل كل رسالة ثم نسخها منفردة.',setting('language','العربية'))))
        outer.addWidget(QLabel(f'{translate_message("الفترة:",setting("language","العربية"))} {start}  —  {end}     |     {translate_message("عدد الشركات:",setting("language","العربية"))} {len(grouped)}'))
        scroll=QScrollArea();scroll.setWidgetResizable(True)
        content=QWidget();cards=QVBoxLayout(content);cards.setSpacing(12)
        for info in grouped.values():
            card=QGroupBox(info['name'])
            box=QVBoxLayout(card)
            # A separate message for each company and date, in the requested order:
            # company, meters/grade, Pump, YYYY/MM/DD.
            # Multiple dates are separated by a blank line and repeated company name.
            lines=[]
            for day,loads in info['days'].items():
                if lines:lines.append('')
                lines.append(info['name'])
                remarks=[]
                for qty,grade,bem,qty2,grade2,note in loads:
                    lines.extend(whatsapp_lines(qty,grade,qty2,grade2))
                    if bem:
                        marker='Pump' if 'Pump' in bem else ('Screed' if 'Screed' in bem else str(bem).strip())
                        if marker and marker not in remarks:remarks.append(marker)
                    if note and note.strip() not in remarks:remarks.append(note.strip())
                lines.extend(remarks)
                lines.append(day.replace('-','/'))
            editor=QTextEdit();editor.setPlainText('\n'.join(lines).strip())
            editor.setMinimumHeight(min(240,max(110,45+len(lines)*19)))
            box.addWidget(editor)
            actions=QHBoxLayout()
            copy_btn=self.button('نسخ رسالة هذه الشركة',lambda checked=False,e=editor:QApplication.clipboard().setText(e.toPlainText()))
            actions.addWidget(copy_btn);actions.addStretch()
            box.addLayout(actions);cards.addWidget(card)
        cards.addStretch();scroll.setWidget(content);outer.addWidget(scroll)
        dialog_actions=QHBoxLayout()
        close_btn=self.button('إغلاق',dlg.accept);dialog_actions.addWidget(close_btn);outer.addLayout(dialog_actions)
        self.translate_dialog(dlg);dlg.exec()

    def refresh_company_pages(self):
        old=self.company_pages.currentWidget()
        old_id=old.property('company_id') if old else None
        self.company_pages.blockSignals(True)
        while self.company_pages.count():
            w=self.company_pages.widget(0);self.company_pages.removeTab(0);w.deleteLater()
        for cid,name in db.execute('SELECT id,name FROM companies ORDER BY name').fetchall():
            page=QWidget();page.setProperty('company_id',cid);lay=QVBoxLayout(page)
            heading=QLabel(name);heading.setStyleSheet('font-size:20px;font-weight:bold;padding:10px');lay.addWidget(heading)
            toolbar=QHBoxLayout()
            toolbar.addWidget(self.button('إضافة تجهيز',lambda checked=False,cid=cid:self.open_company_load(cid)))
            toolbar.addWidget(self.button('Excel',lambda checked=False,cid=cid:self.export_company(cid,'xlsx')))
            toolbar.addWidget(self.button('PDF',lambda checked=False,cid=cid:self.export_company(cid,'pdf')))
            lay.addLayout(toolbar)
            rows=db.execute("""SELECT id,day,details,bem,grade,qty,unit_price,qty*unit_price FROM deliveries
                WHERE company_id=? AND grade<>'' UNION ALL
                SELECT id,day,details,bem,grade2,qty2,unit_price2,qty2*unit_price2 FROM deliveries
                WHERE company_id=? AND grade2<>'' ORDER BY day DESC""",(cid,cid)).fetchall()
            table=self.table(['رقم','تاريخ التجهيز','التفاصيل','بم','النوعية','عدد الأمتار','سعر المتر','السعر الكلي']);table.setRowCount(len(rows))
            for i,vals in enumerate(rows):
                for j,value in enumerate(vals):table.setItem(i,j,item(money(value) if j in (6,7) else value))
            table.setSelectionMode(QAbstractItemView.ExtendedSelection)
            lay.addWidget(table)
            toolbar.addWidget(self.button('حذف المحدد',lambda checked=False,t=table:self.delete_company_page_rows(t)))
            toolbar.addWidget(self.button('Clear All',lambda checked=False,cid=cid:self.clear_company_records(cid)))
            total=sum(r[5]*r[6] for r in rows)
            paid=db.execute('SELECT COALESCE(SUM(amount),0) FROM payments WHERE company_id=?',(cid,)).fetchone()[0]
            lang=setting('language','العربية')
            summary_words={'العربية':('الإجمالي','التسديدات','المتبقي'),'English':('Total','Payments','Balance'),
                           'Türkçe':('Toplam','Ödemeler','Bakiye'),'简体中文':('总额','付款','余额'),
                           'বাংলা':('মোট','পেমেন্ট','বাকি'),'اردو':('کل','ادائیگیاں','بقایا')}
            a,b,c=summary_words.get(lang,summary_words['العربية'])
            summary=QLabel(f'{a}: {money(total)} IQD     |     {b}: {money(paid)} IQD     |     {c}: {money(total-paid)} IQD')
            summary.setProperty('company_summary',True);lay.addWidget(summary)
            self.company_pages.addTab(page,name)
            if cid==old_id:self.company_pages.setCurrentWidget(page)
        self.company_pages.blockSignals(False)
        if hasattr(self,'lang'):self.apply_language()

    def open_company_load(self,cid):
        self.l_company.setCurrentIndex(self.l_company.findData(cid));self.tabs.setCurrentWidget(self.load_tab)

    def export_company(self,cid,ext):
        self.e_company.setCurrentIndex(self.e_company.findData(cid));self.export(ext)

    def make_payments(self):
        l=self.layout(self.pay_tab);form=QGroupBox('تسجيل تسديد مستقل عن التجهيزات');f=QFormLayout(form)
        self.p_company=self.company_combo();self.p_date=self.datefield();self.p_amount=QDoubleSpinBox();self.p_amount.setRange(.01,1e12);self.p_amount.setDecimals(0);self.p_note=QLineEdit()
        for n,w in [('تاريخ التسديد',self.p_date),('الشركة',self.p_company),('المبلغ (د.ع)',self.p_amount)]:f.addRow(n,w)
        self.p_note_toggle=QCheckBox('إضافة ملاحظة / رقم الوصل');f.addRow(self.p_note_toggle)
        f.addRow('ملاحظة / رقم الوصل',self.p_note)
        note_label=f.labelForField(self.p_note)
        self.p_note_toggle.toggled.connect(lambda checked:(self.p_note.setVisible(checked),note_label.setVisible(checked)))
        self.p_note.hide();note_label.hide()
        l.addWidget(form);form.setSizePolicy(QSizePolicy.Preferred,QSizePolicy.Maximum);r=QHBoxLayout();r.addWidget(self.button('إدراج التسديد',self.save_payment));r.addWidget(self.button('تعديل المحدد',self.edit_payment));r.addWidget(self.button('حذف المحدد بعد التأكيد',self.delete_payment));l.addLayout(r)
        self.p_table=self.table(['رقم','الشركة','التاريخ','المبلغ','ملاحظة / رقم الوصل']);l.addWidget(self.p_table,1);self.payment_edit=None
    def save_payment(self):
        id=self.p_company.currentData()
        if not id:return
        vals=(id,self.p_date.date().toString('yyyy-MM-dd'),self.p_amount.value(),self.p_note.text())
        if self.payment_edit:db.execute('UPDATE payments SET company_id=?,day=?,amount=?,note=? WHERE id=?',(*vals,self.payment_edit))
        else:db.execute('INSERT INTO payments(company_id,day,amount,note) VALUES(?,?,?,?)',vals)
        db.commit();self.payment_edit=None;self.p_note.clear();self.p_note_toggle.setChecked(False);self.refresh_all()
    def edit_payment(self):
        r=self.p_table.currentRow()
        if r<0:return
        id=int(self.p_table.item(r,0).text());x=db.execute('SELECT company_id,day,amount,note FROM payments WHERE id=?',(id,)).fetchone()
        if x:self.payment_edit=id;self.p_company.setCurrentIndex(self.p_company.findData(x[0]));self.p_date.setDate(QDate.fromString(x[1],'yyyy-MM-dd'));self.p_amount.setValue(x[2]);self.p_note.setText(x[3]);self.p_note_toggle.setChecked(bool(x[3]))
    def delete_payment(self):
        ids=[int(self.p_table.item(i.row(),0).text()) for i in self.p_table.selectionModel().selectedRows()]
        if not ids:return
        if self.message('question',self,'تأكيد حذف تسديد',f'هل تريد حذف {len(ids)} تسديد؟ هذه العملية تؤثر على الرصيد المالي.')!=QMessageBox.Yes:return
        db.executemany('DELETE FROM payments WHERE id=?',[(x,) for x in ids]);db.commit();self.refresh_all()
    def make_export(self):
        l=self.layout(self.export_tab)
        l.addWidget(QLabel('معاينة التجهيزات قبل تصدير Excel / PDF'))
        form=QFormLayout();form.setSpacing(3)
        self.e_company=self.company_combo()
        self.e_start=self.datefield();self.e_start.setDate(QDate(2020,1,1))
        self.e_end=self.datefield()
        form.addRow('الشركة (ALL لجميع الشركات)',self.e_company)
        form.addRow('من تاريخ',self.e_start);form.addRow('إلى تاريخ',self.e_end)
        l.addLayout(form)
        date_actions=QHBoxLayout()
        date_actions.addWidget(self.button('اليوم | Today',lambda:self.e_end.setDate(QDate.currentDate())))
        date_actions.addWidget(self.button('اليوم فقط | Today Only',self.report_today_only))
        date_actions.addStretch()
        l.addLayout(date_actions)
        self.e_company.currentIndexChanged.connect(self.refresh_export_preview)
        self.e_start.dateChanged.connect(self.refresh_export_preview)
        self.e_end.dateChanged.connect(self.refresh_export_preview)
        options=QHBoxLayout()
        self.e_separate=QRadioButton('ملف مستقل لكل شركة');self.e_combined=QRadioButton('كشف موحد لجميع الشركات')
        self.e_separate.setChecked(True)
        options.addWidget(self.e_separate);options.addWidget(self.e_combined);options.addStretch()
        l.addLayout(options)
        self.e_preview=self.table(['✓','الشركة','تاريخ التجهيز','التفاصيل','بم','النوعية','الأمتار م³','سعر المتر','الإجمالي','الملاحظات'])
        self.e_preview.setMinimumHeight(300)
        self.e_preview.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.e_preview.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.e_preview.setColumnWidth(0,45)
        self.e_preview.itemChanged.connect(self.preview_selection_changed)
        l.addWidget(self.e_preview,1)
        select_row=QHBoxLayout()
        select_row.addWidget(self.button('Select All | تحديد الكل',lambda:self.set_preview_checks(True)))
        select_row.addWidget(self.button('Deselect All | إلغاء التحديد',lambda:self.set_preview_checks(False)))
        select_row.addWidget(self.button('تحديث المعاينة',self.refresh_export_preview))
        select_row.addStretch()
        l.addLayout(select_row)
        self.summary=QLabel();self.summary.setWordWrap(True);l.addWidget(self.summary)
        actions=QHBoxLayout()
        actions.addWidget(self.button('حذف تجهيزات الفترة',self.delete_report_deliveries))
        actions.addWidget(self.button('Clear All (الشركة والفترة)',self.clear_report_records))
        actions.addStretch()
        l.addLayout(actions)
        l.addWidget(QLabel('الحذف يتطلب تأكيداً ونسخة احتياطية. إلغاء تحديد صف لا يحذفه من قاعدة البيانات.'))
        self._preview_keys=[]
    def preview_rows(self):
        if not hasattr(self,'e_preview'):return []
        company=self.e_company.currentData()
        start=self.e_start.date().toString('yyyy-MM-dd')
        end=self.e_end.date().toString('yyyy-MM-dd')
        if start>end:return []
        query="""SELECT d.id,c.id,c.name,d.day,d.details,d.bem,d.grade,d.qty,d.unit_price,d.notes,
                        d.grade2,d.qty2,d.unit_price2
                 FROM deliveries d JOIN companies c ON c.id=d.company_id
                 WHERE d.day BETWEEN ? AND ?"""
        params=[start,end]
        if company is not None:
            query+=' AND c.id=?';params.append(company)
        query+=' ORDER BY c.name COLLATE NOCASE,d.day,d.id'
        result=[]
        for r in db.execute(query,params):
            did,cid,name,day,details,bem,g1,q1,p1,notes,g2,q2,p2=r
            if g1 and float(q1 or 0)>0:
                result.append(((did,1),cid,name,(did,day,details,bem,g1,float(q1),float(p1),notes),name))
            if g2 and float(q2 or 0)>0:
                result.append(((did,2),cid,name,(did,day,details,bem,g2,float(q2),float(p2),notes),name))
        return result
    def refresh_export_preview(self,*_):
        if not hasattr(self,'e_preview'):return
        old={self._preview_keys[i]:self.e_preview.item(i,0).checkState()==Qt.Checked
             for i in range(min(len(getattr(self,'_preview_keys',[])),self.e_preview.rowCount()))
             if self.e_preview.item(i,0)}
        records=self.preview_rows();self._preview_keys=[r[0] for r in records]
        self.e_preview.blockSignals(True);self.e_preview.setRowCount(len(records))
        for i,(key,cid,name,delivery,_) in enumerate(records):
            check=QTableWidgetItem();check.setFlags(Qt.ItemIsEnabled|Qt.ItemIsUserCheckable|Qt.ItemIsSelectable)
            check.setCheckState(Qt.Checked if old.get(key,True) else Qt.Unchecked)
            self.e_preview.setItem(i,0,check)
            d=delivery
            values=[name,d[1],d[2],d[3],d[4],f'{d[5]:g}',money(d[6]),money(d[5]*d[6]),d[7]]
            for j,value in enumerate(values,1):self.e_preview.setItem(i,j,item(value))
        self.e_preview.blockSignals(False)
        self.update_summary()
    def set_preview_checks(self,checked):
        self.e_preview.blockSignals(True)
        for i in range(self.e_preview.rowCount()):self.e_preview.item(i,0).setCheckState(Qt.Checked if checked else Qt.Unchecked)
        self.e_preview.blockSignals(False);self.update_summary()
    def preview_selection_changed(self,cell):
        if cell.column()==0:self.update_summary()
    def selected_preview(self):
        keys={self._preview_keys[i] for i in range(min(self.e_preview.rowCount(),len(self._preview_keys)))
              if self.e_preview.item(i,0) and self.e_preview.item(i,0).checkState()==Qt.Checked}
        return [r for r in self.preview_rows() if r[0] in keys]
    def company_data(self):
        rows=[r[3] for r in self.selected_preview()]
        selected_companies={r[1] for r in self.selected_preview()}
        start=self.e_start.date().toString('yyyy-MM-dd');end=self.e_end.date().toString('yyyy-MM-dd')
        pays=[]
        if len(selected_companies)==1:
            cid=next(iter(selected_companies))
            pays=db.execute('SELECT day,amount,note FROM payments WHERE company_id=? AND day BETWEEN ? AND ? ORDER BY day,id',(cid,start,end)).fetchall()
        return rows,pays
    def update_summary(self,*_):
        if not hasattr(self,'summary') or not hasattr(self,'e_preview'):return
        selected=self.selected_preview()
        companies=len({r[1] for r in selected})
        meters=sum(r[3][5] for r in selected)
        total=sum(r[3][5]*r[3][6] for r in selected)
        self.summary.setText(f'الشركات المحددة: {companies}  |  صفوف التجهيز: {len(selected)}  |  الأمتار: {meters:g} م³  |  القيمة: {money(total)} IQD  |  الكشف الموحد متعدد الشركات يعرض التجهيزات فقط دون التسديدات')
    def export(self,ext):
        selected=self.selected_preview()
        if not selected:return self.message('warning',self,'تنبيه','حدد تجهيزاً واحداً على الأقل للتصدير.')
        start=self.e_start.date().toString('yyyy-MM-dd');end=self.e_end.date().toString('yyyy-MM-dd')
        grouped={}
        for key,cid,name,delivery,_ in selected:
            grouped.setdefault(cid,{'name':name,'rows':[]})['rows'].append(delivery)
        try:
            if self.e_company.currentData() is not None or self.e_combined.isChecked():
                # Combined statements label each delivery with its company name.
                if len(grouped)>1:
                    rows=[]
                    for info in grouped.values():
                        for d in info['rows']:
                            d=list(d);d[2]=f'{info["name"]} | {d[2]}' if d[2] else info['name']
                            rows.append(tuple(d))
                    company_name='ALL – جميع الشركات (تجهيزات فقط)'
                    pays=[] # combined exports intentionally omit unallocated payments
                else:
                    info=next(iter(grouped.values()))
                    rows=info['rows'];company_name=info['name']
                    cid=next(iter(grouped))
                    pays=db.execute('SELECT day,amount,note FROM payments WHERE company_id=? AND day BETWEEN ? AND ? ORDER BY day,id',(cid,start,end)).fetchall()
                safe=re.sub(r'[\\/:*?"<>|]', '_',company_name)
                path,_=QFileDialog.getSaveFileName(self,'حفظ الكشف',f'{safe}_كشف_الكونكريت.{ext}',f'{ext.upper()} (*.{ext})')
                if not path:return
                if not path.lower().endswith('.'+ext):path+='.'+ext
                (xlsx_export if ext=='xlsx' else pdf_export)(path,company_name,rows,pays)
                result=path
            else:
                folder=QFileDialog.getExistingDirectory(self,'اختر مجلد حفظ كشوف الشركات')
                if not folder:return
                result=[]
                for cid,info in grouped.items():
                    safe=re.sub(r'[\\/:*?"<>|]', '_',info['name']).strip(' .') or f'Company_{cid}'
                    path=str(Path(folder)/f'{safe}_{cid}_كشف_الكونكريت.{ext}')
                    pays=db.execute('SELECT day,amount,note FROM payments WHERE company_id=? AND day BETWEEN ? AND ? ORDER BY day,id',(cid,start,end)).fetchall()
                    (xlsx_export if ext=='xlsx' else pdf_export)(path,info['name'],info['rows'],pays)
                    result.append(path)
                result='\n'.join(result)
            self.message('information',self,'تم','تم حفظ الكشف بنجاح:\n'+result)
        except Exception as e:self.message('critical',self,'خطأ التصدير',str(e))
    def make_whatsapp_tab(self):
        lay=self.layout(self.whatsapp_tab)
        header=QHBoxLayout()
        header.addWidget(QLabel('رسائل واتساب | WhatsApp'))
        header.addStretch()
        lay.addLayout(header)
        filters=QHBoxLayout()
        filters.addWidget(QLabel('الشركة:'))
        self.w_company=QComboBox()
        self.w_company.addItem('ALL – جميع الشركات',None)
        for cid,cname in db.execute('SELECT id,name FROM companies ORDER BY name'):
            self.w_company.addItem(cname,cid)
        filters.addWidget(self.w_company)
        filters.addWidget(QLabel('اختيار الحمولات:'))
        self.w_load_choice=QComboBox()
        self.w_load_choice.setMinimumWidth(210)
        filters.addWidget(self.w_load_choice)
        filters.addWidget(QLabel('لغة الرسالة:'))
        self.w_language=QComboBox()
        self.w_language.addItems(['العربية','English','Türkçe','简体中文','বাংলা','اردو'])
        filters.addWidget(self.w_language)
        filters.addStretch()
        lay.addLayout(filters)
        self.w_preview=QTextEdit();self.w_preview.setObjectName('whatsappPreview')
        self.w_preview.setPlaceholderText('اختر الحمولات لعرض الرسالة. يمكنك تعديل النص قبل النسخ.')
        lay.addWidget(self.w_preview,1)
        actions=QHBoxLayout()
        actions.addWidget(self.button('تحديث الرسالة',self.refresh_whatsapp_inline))
        actions.addWidget(self.button('نسخ إلى واتساب',self.copy_whatsapp_inline))
        actions.addWidget(self.button('إغلاق المعاينة',lambda:self.w_preview.clear()))
        actions.addStretch()
        lay.addLayout(actions)
        export_bar=QHBoxLayout()
        export_bar.addWidget(QLabel('تصدير الكشوفات المحددة:'))
        export_bar.addWidget(self.button('Excel',lambda:self.export('xlsx')))
        export_bar.addWidget(self.button('PDF',lambda:self.export('pdf')))
        export_bar.addStretch()
        lay.addLayout(export_bar)
        lay.addWidget(QLabel('التصدير يستخدم الشركة والفترة والصفوف المحددة في صفحة الكشوفات.'))
        self._whatsapp_records=[]
        self.w_company.currentIndexChanged.connect(self.refresh_whatsapp_inline)
        self.tabs.currentChanged.connect(lambda _index: self.refresh_whatsapp_inline() if self.tabs.currentWidget() is self.whatsapp_tab else None)
        self.w_load_choice.currentIndexChanged.connect(self.show_whatsapp_inline_message)
        self.w_language.currentIndexChanged.connect(self.show_whatsapp_inline_message)
        self.refresh_whatsapp_inline()
    def report_today_only(self):
        today=QDate.currentDate()
        self.e_start.setDate(today)
        self.e_end.setDate(today)
        self.refresh_export_preview()
    def refresh_whatsapp_inline(self,*_):
        if not hasattr(self,'w_load_choice'):return
        old=self.w_load_choice.currentData()
        company_id=self.w_company.currentData()
        query="""SELECT d.id,c.id,c.name,d.day,d.details,d.qty,d.grade,d.bem,d.qty2,d.grade2,d.notes
                 FROM deliveries d JOIN companies c ON c.id=d.company_id"""
        params=[]
        if company_id is not None:
            query+=' WHERE c.id=?';params.append(company_id)
        query+=' ORDER BY c.name COLLATE NOCASE,d.day,d.id'
        self._whatsapp_records=db.execute(query,params).fetchall()
        self.w_load_choice.blockSignals(True)
        self.w_load_choice.clear()
        self.w_load_choice.addItem('جميع الحمولات',None)
        for rec in self._whatsapp_records:
            did,cid,name,day,details,qty,grade,bem,qty2,grade2,note=rec
            self.w_load_choice.addItem(f'{name} | {day} | {float(qty or 0):g} م³ {grade}',did)
        ix=self.w_load_choice.findData(old)
        self.w_load_choice.setCurrentIndex(ix if ix>=0 else 0)
        self.w_load_choice.blockSignals(False)
        self.show_whatsapp_inline_message()
    def show_whatsapp_inline_message(self,*_):
        if not hasattr(self,'w_preview'):return
        chosen=self.w_load_choice.currentData()
        lang=self.w_language.currentText()
        unit={'العربية':'م³','English':'m³','Türkçe':'m³','简体中文':'立方米',
              'বাংলা':'ঘনমিটার','اردو':'مکعب میٹر'}.get(lang,'m³')
        note_label={'العربية':'ملاحظة','English':'Note','Türkçe':'Not','简体中文':'备注',
                    'বাংলা':'মন্তব্য','اردو':'نوٹ'}.get(lang,'Note')
        grouped={}
        for did,cid,name,day,details,qty,grade,bem,qty2,grade2,note in self._whatsapp_records:
            if chosen is not None and chosen!=did:continue
            # Every company has its own clearly separated message block.
            lines=[]
            if details and details.strip():lines.append(details.strip())
            old_screed=bool(bem and ('Screed' in bem or 'سكرييد' in bem))
            display_grade=grade or ('Screed - سكرييد' if old_screed else '')
            if qty and display_grade:lines.append(f'{float(qty):g} {unit} - {display_grade}')
            if qty2 and grade2:lines.append(f'{float(qty2):g} {unit} - {grade2}')
            if bem and bem.strip() and not old_screed:lines.append(bem.strip())
            if note and note.strip():lines.append(f'{note_label}: {note.strip()}')
            lines.append(day.replace('-','/'))
            grouped.setdefault((cid,name),[]).append('\n'.join(lines))
        blocks=[]
        for (_,name),messages in grouped.items():
            blocks.append(name+'\n'+'\n\n'.join(messages))
        self.w_preview.setPlainText(('\n\n'+'━'*25+'\n\n').join(blocks) if blocks else 'لا توجد حمولات محفوظة.')
    def copy_whatsapp_inline(self):
        content=self.w_preview.toPlainText().strip()
        if not self._whatsapp_records or not content or content=='لا توجد حمولات محفوظة.':
            return self.message('information',self,'تنبيه','لا توجد حمولات محفوظة.')
        QApplication.clipboard().setText(content)
        self.message('information',self,'تم','تم نسخ الرسالة. يمكنك لصقها في الواتساب.')
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Wheel and QApplication.keyboardModifiers() & Qt.ControlModifier:
            current=int(setting('scale','100'))
            delta=event.angleDelta().y()
            new=max(80,min(150,current+(10 if delta>0 else -10)))
            if new!=current:
                set_setting('scale',new)
                if hasattr(self,'scale'):
                    self.scale.blockSignals(True);self.scale.setValue(new);self.scale.blockSignals(False)
                self.apply_theme()
            return True
        return super().eventFilter(obj,event)
    def automatic_backup(self):
        folder=ROOT/'backups';folder.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        path=folder/f'concrete_before_delete_{stamp}.db'
        with sqlite3.connect(path) as dest:db.backup(dest)
        return path
    def guarded_delete(self,kind,ids,scope):
        ids=sorted(set(int(x) for x in ids))
        if not ids:
            return self.message('information',self,'تنبيه','لا توجد سجلات للحذف.')
        label='تجهيزات' if kind=='deliveries' else 'تسديدات'
        if self.message('question',self,'تأكيد',f'سيتم حذف {len(ids)} {label} من {scope}. هل تريد المتابعة؟')!=QMessageBox.Yes:return
        if len(ids)>1 and self.message('question',self,'تأكيد',f'تأكيد نهائي: حذف {len(ids)} سجلات؟ سيتم حفظ نسخة احتياطية أولاً.')!=QMessageBox.Yes:return
        try:
            backup=self.automatic_backup()
            with db:
                db.executemany(f'DELETE FROM {kind} WHERE id=?',[(x,) for x in ids])
            self.refresh_all();self.refresh_company_pages();self.refresh_export_preview()
            self.message('information',self,'تم',f'تم حذف {len(ids)} سجلات.\\nنسخة احتياطية: {backup}')
        except Exception as exc:self.message('critical',self,'تنبيه',str(exc))
    def delete_company_page_rows(self,table):
        ids=[int(table.item(i.row(),0).text()) for i in table.selectionModel().selectedRows()]
        self.guarded_delete('deliveries',ids,'كشف الشركة')
    def clear_company_records(self,cid):
        name=db.execute('SELECT name FROM companies WHERE id=?',(cid,)).fetchone()
        if not name:return
        ids=[r[0] for r in db.execute('SELECT id FROM deliveries WHERE company_id=?',(cid,))]
        self.guarded_delete('deliveries',ids,name[0])
    def report_ids(self,kind):
        cid=self.e_company.currentData()
        if cid is None:
            return sorted({key[0] for key,_,_,_,_ in self.selected_preview()})
        start=self.e_start.date().toString('yyyy-MM-dd')
        end=self.e_end.date().toString('yyyy-MM-dd')
        return [r[0] for r in db.execute(f'SELECT id FROM {kind} WHERE company_id=? AND day BETWEEN ? AND ?',(cid,start,end))]
    def delete_report_deliveries(self):
        self.guarded_delete('deliveries',self.report_ids('deliveries'),'الشركة والفترة المحددتين')
    def clear_report_records(self):
        # Clear All is deliberately scoped to deliveries for selected company/date range.
        # Payments are never silently removed.
        self.guarded_delete('deliveries',self.report_ids('deliveries'),'الشركة والفترة المحددتين؛ التسديدات محفوظة')
    def make_settings(self):
        outer=self.layout(self.settings_tab)
        scroll=QScrollArea();scroll.setWidgetResizable(True);outer.addWidget(scroll)
        content=QWidget();scroll.setWidget(content)
        grid=QVBoxLayout(content);grid.setSpacing(12)
        appearance=QGroupBox('المظهر والتخصيص');form=QFormLayout(appearance)
        self.theme=QComboBox()
        for key in ('هوية الجابر','فاتح','داكن','Clean Office','Midnight Blue','Soft Sage','Graphite Gray','High Contrast','Royal Gold','Cyber Glass','Crystal Light','Industrial Pro'):
            self.theme.addItem(key,key)
        self.theme.setCurrentIndex(max(0,self.theme.findData(setting('theme','هوية الجابر'))))
        self.theme.currentIndexChanged.connect(lambda i:(set_setting('theme',self.theme.itemData(i)),self.apply_theme()))
        self.lang=QComboBox();self.lang.addItems(LANGUAGES)
        self.lang.setCurrentText(setting('language','العربية'));self.lang.currentTextChanged.connect(self.language_changed)
        self.font_picker=QComboBox()
        self.font_picker.addItems(['Segoe UI','Tahoma','Arial','Cairo','Tajawal','Noto Sans'])
        self.font_picker.setCurrentText(setting('font','Segoe UI'))
        self.font_picker.currentTextChanged.connect(lambda v:(set_setting('font',v),self.apply_theme()))
        self.font_size=QSpinBox();self.font_size.setRange(10,22)
        self.font_size.setValue(int(setting('font_size','12')))
        self.font_size.valueChanged.connect(lambda v:(set_setting('font_size',v),self.apply_theme()))
        self.scale=QSpinBox();self.scale.setRange(80,150);self.scale.setSingleStep(10)
        self.scale.setSuffix('%');self.scale.setValue(int(setting('scale','100')))
        self.scale.valueChanged.connect(lambda v:(set_setting('scale',v),self.apply_theme()))
        self.density=QComboBox()
        for key,label in [('small','صغير'),('medium','متوسط'),('large','كبير')]:self.density.addItem(label,key)
        self.density.setCurrentIndex(max(0,self.density.findData(setting('density','medium'))))
        self.density.currentIndexChanged.connect(lambda i:(set_setting('density',self.density.itemData(i)),self.apply_density()))
        self.nav_style=QComboBox()
        for key,label in [('minimal','Clean & Minimalist'),('emoji','Visual Emoji + Text'),('technical','Sleek & Technical'),('action','Action-Oriented'),('short','Ultra-Short Aesthetic')]:
            self.nav_style.addItem(label,key)
        self.nav_style.setCurrentIndex(max(0,self.nav_style.findData(setting('nav_style','minimal'))))
        self.nav_style.currentIndexChanged.connect(lambda i:(set_setting('nav_style',self.nav_style.itemData(i)),self.apply_navigation_style()))
        for label,widget in [('المظهر',self.theme),('اللغة',self.lang),('نوع الخط',self.font_picker),
                             ('حجم الخط',self.font_size),('حجم الواجهة',self.scale),('حجم الخانات',self.density),
                             ('تصميم التنقل',self.nav_style)]:form.addRow(label,widget)
        grid.addWidget(appearance)
        layouts=QGroupBox('تصميم الواجهة | Layout Design')
        layout_form=QFormLayout(layouts)
        self.layout_picker=QComboBox()
        for key,label in [
            ('modern','1. Modern Dashboard'),
            ('erp','2. Professional ERP'),
            ('glass','3. Futuristic Glass'),
            ('minimal','4. Minimal Workspace'),
            ('industrial','5. AL-JABER Industrial')]:
            self.layout_picker.addItem(label,key)
        self.layout_picker.setCurrentIndex(max(0,self.layout_picker.findData(setting('layout_design','industrial'))))
        self.layout_picker.currentIndexChanged.connect(self.change_layout_design)
        layout_form.addRow('تصميم الواجهة',self.layout_picker)
        self.load_columns_picker=QComboBox()
        for number in (3,4,5,6):self.load_columns_picker.addItem(f'{number} خانات في السطر',number)
        saved_columns=int(setting('load_columns','4'))
        self.load_columns_picker.setCurrentIndex(max(0,self.load_columns_picker.findData(saved_columns)))
        self.load_columns_picker.currentIndexChanged.connect(self.change_load_columns)
        layout_form.addRow('توزيع خانات التجهيزات',self.load_columns_picker)
        grid.addWidget(layouts)
        grid.addWidget(self.button('استعادة التصميم الافتراضي',self.reset_appearance))
        grid.addWidget(self.button('حول البرنامج | About',self.show_about))
        backup=QGroupBox('البيانات والنسخ الاحتياطية');b=QVBoxLayout(backup)
        b.addWidget(QLabel('قاعدة البيانات محفوظة في: '+str(ROOT/'concrete.db')))
        b.addWidget(self.button('حفظ نسخة احتياطية من قاعدة البيانات',self.backup))
        grid.addWidget(backup);grid.addStretch()
    def language_changed(self,v):
        set_setting('language',v)
        self.apply_language()
        self.refresh_company_pages()
    def backup(self):
        from shutil import copy2
        p,_=QFileDialog.getSaveFileName(self,'حفظ نسخة احتياطية','concrete_backup.db','SQLite (*.db)')
        if p:
            db.commit();target=sqlite3.connect(p)
            with target:db.backup(target)
            target.close();self.message('information',self,'تم','تم حفظ النسخة الاحتياطية')
    def apply_language(self):
        lang=setting('language','العربية')
        en=lang=='English'
        dictionary={
            'الشركات':'Companies','التجهيزات':'Deliveries','التسديدات':'Payments','الكشوفات':'Excel / PDF Reports',
            'الإعدادات':'Settings','كشوف الشركات':'Company Tabs','إضافة شركة / مقاول جديد':'Add a company / contractor',
            'إضافة شركة':'Add Company','تعديل الاسم':'Rename','اسم الشركة':'Company Name',
            'كل شركة لها كشف مستقل، ويمكن اختيارها من الصفحات الأخرى.':'Each company has its own report and tab.',
            'بيانات تجهيز الكونكريت':'Concrete Delivery','الشركة':'Company','تاريخ التجهيز':'Delivery Date',
            'التفاصيل / الموقع':'Details / Site','بم':'Pump / Screed','نوع الكونكريت':'Concrete Grade',
            'عدد الأمتار (م³)':'Quantity (m³)','سعر المتر (د.ع)':'Unit Price (IQD)',
            'نوع الكونكريت الثاني (اختياري)':'Second Concrete Grade (Optional)',
            'الأمتار الثانية (م³)':'Second Quantity (m³)','سعر المتر الثاني (د.ع)':'Second Unit Price (IQD)',
            'الملاحظات':'Notes','السعر الكلي':'Total Price','حفظ تجهيز جديد':'Save Delivery',
            'تعديل السطر المحدد':'Edit Selected','حذف السطر المحدد':'Delete Selected',
            'إنشاء رسالة واتساب':'Create WhatsApp Message','رسائل واتساب لجميع الشركات (رسالة مستقلة لكل شركة)':'WhatsApp for All Companies (Separate Messages)','تسجيل تسديد مستقل عن التجهيزات':'Record Separate Payment',
            'تاريخ التسديد':'Payment Date','المبلغ (د.ع)':'Amount (IQD)','ملاحظة / رقم الوصل':'Note / Receipt No.',
            'حفظ تسديد':'Save Payment','تعديل المحدد':'Edit Selected','حذف المحدد بعد التأكيد':'Delete Selected',
            'كشف احترافي للشركة بتصميم هوية الجابر':'Professional company report in Al-Jaber style',
            'من تاريخ':'From','إلى تاريخ':'To','تصدير Excel':'Export Excel','تصدير PDF':'Export PDF',
            'المظهر والتخصيص':'Appearance','المظهر':'Theme','اللغة':'Language',
            'نوع الخط':'Font Family','حجم الخط':'Font Size','حجم الواجهة':'Interface Scale',
            'حجم الخانات':'Row / Field Size','تصميم التنقل':'Navigation Layout',
            'استعادة التصميم الافتراضي':'Restore Default Appearance',
            'البيانات والنسخ الاحتياطية':'Data and Backups',
            'حفظ نسخة احتياطية من قاعدة البيانات':'Back Up Database',
            'إضافة تجهيز':'Add Delivery','رسالة واتساب':'WhatsApp Message',
            'رقم':'ID','التاريخ':'Date','التفاصيل':'Details','النوعية':'Grade','الأمتار':'Quantity',
            'سعر المتر':'Unit Price','الإجمالي':'Total','ملاحظات':'Notes','المبلغ':'Amount','الملاحظة':'Note',
            'عدد الأمتار':'Quantity','مبلغ التسديد':'Payment Amount',
            'تحديث الرسالة':'Refresh Message','نسخ رسالة الواتساب':'Copy WhatsApp Message',
            'نسخ رسالة هذه الشركة':'Copy This Company Message','إغلاق':'Close',
            'اختر تاريخ التجهيز ثم حدد الأسطر التي تريد تضمينها في الرسالة':'Select a delivery date and the rows to include in the message',
            'ستظهر رسالة الواتساب هنا ويمكنك تعديلها قبل النسخ':'Your WhatsApp message will appear here; you can edit it before copying.',
            'الكمية م³':'Quantity (m³)','الأمتار 2':'Quantity 2','النوعية 2':'Grade 2','الملاحظات':'Notes',
            'المظهر والتخصيص':'Appearance and Customization',
            'البيانات والنسخ الاحتياطية':'Data and Backups',
            'حفظ نسخة احتياطية من قاعدة البيانات':'Back Up Database',
        }
        self.setWindowTitle('AL-JABER Concrete 2026 | '+('Concrete Management' if en else translate_message('بيانات تجهيز الكونكريت',lang)))
        self.setLayoutDirection(Qt.RightToLeft if lang in ('العربية','اردو') else Qt.LeftToRight)
        titles=[('الشركات','Companies'),('التجهيزات','Deliveries'),('التسديدات','Payments'),('الكشوفات','Excel / PDF Reports'),('كشوف الشركات','Company Tabs'),('رسائل واتساب','WhatsApp'),('الإعدادات','Settings')]
        for i,(ar,eng) in enumerate(titles):
            if i<self.tabs.count() and self.tabs.widget(i) is not getattr(self,'production_tab',None):self.tabs.setTabText(i,eng if en else translate_message(ar,lang))
        if hasattr(self,'production_tab'):
            self.tabs.setTabText(self.tabs.indexOf(self.production_tab),'Production Report')
            self.tabs.setTabText(self.tabs.indexOf(self.settings_tab),'Settings' if en else 'الإعدادات')
        if not hasattr(self,'_translation_sources'):self._translation_sources={}
        widgets=[self]+self.findChildren(QWidget)
        for w in widgets:
            if isinstance(w,(QLabel,QPushButton,QGroupBox,QCheckBox)):
                if w.property('company_summary'):continue
                original=w.property('source_text')
                if original is None:
                    original=w.title() if isinstance(w,QGroupBox) else w.text();w.setProperty('source_text',original)
                value=dictionary.get(original,original) if en else translate_message(original,lang)
                if isinstance(w,QGroupBox):w.setTitle(value)
                else:w.setText(value)
            elif isinstance(w,QLineEdit):
                original=w.property('source_placeholder')
                if original is None:
                    original=w.placeholderText();w.setProperty('source_placeholder',original)
                w.setPlaceholderText(dictionary.get(original,original) if en else translate_message(original,lang))
            elif isinstance(w,QTableWidget):
                originals=w.property('source_headers')
                if originals is None:originals=[w.horizontalHeaderItem(j).text() if w.horizontalHeaderItem(j) else '' for j in range(w.columnCount())];w.setProperty('source_headers',originals)
                for j,original in enumerate(originals):w.horizontalHeaderItem(j).setText(dictionary.get(original,original) if en else translate_message(original,lang)) if w.horizontalHeaderItem(j) else None
        for i,(ar,english) in enumerate([('هوية الجابر','Al-Jaber Identity'),('فاتح','Light'),('داكن','Dark')]):
            self.theme.setItemText(i,english if en else translate_message(ar,lang))
        density_names={'small':{'English':'Small','Türkçe':'Küçük','简体中文':'小','বাংলা':'ছোট','اردو':'چھوٹا'},
                       'medium':{'English':'Medium','Türkçe':'Orta','简体中文':'中','বাংলা':'মাঝারি','اردو':'درمیانہ'},
                       'large':{'English':'Large','Türkçe':'Büyük','简体中文':'大','বাংলা':'বড়','اردو':'بڑا'}}
        for i,(key,arabic) in enumerate([('small','صغير'),('medium','متوسط'),('large','كبير')]):
            self.density.setItemText(i,density_names[key].get(lang,arabic))
        for page in [self.company_tab,self.load_tab,self.pay_tab,self.export_tab,self.whatsapp_tab,self.settings_tab]:
            for form in page.findChildren(QFormLayout):
                for j in range(form.rowCount()):
                    label=form.itemAt(j,QFormLayout.LabelRole)
                    if label and isinstance(label.widget(),QLabel):
                        w=label.widget();original=w.property('source_text')
                        if original is None:
                            original=w.text();w.setProperty('source_text',original)
                        w.setText(dictionary.get(original,original) if en else translate_message(original,lang))
        if hasattr(self,'load_field_cells'):
            for original,widget,cell in self.load_field_cells:
                label=cell.findChild(QLabel,'loadFieldLabel')
                if label:label.setText(dictionary.get(original,original) if en else translate_message(original,lang))
        self.apply_navigation_style()
        self.apply_theme()
        # Preserve all company names and delivery values as entered by the user.

    def apply_theme(self):
        mode=setting('theme','هوية الجابر')
        palettes={
            'هوية الجابر':('#191d23','#f7f3e9','#252b31','#e39a2b','#4a4a45'),
            'فاتح':('#f2f5fa','#202938','#ffffff','#2765aa','#d8e0eb'),
            'داكن':('#171b23','#eef1f6','#222936','#c99334','#404958'),
            'Clean Office':('#f3f6fa','#203044','#ffffff','#4079b7','#d6e0eb'),
            'Midnight Blue':('#101d2f','#e9f4ff','#1b3049','#31c9d0','#35516c'),
            'Soft Sage':('#e9e5dc','#28372b','#faf9f5','#66806a','#c7cec0'),
            'Graphite Gray':('#25282d','#f0f0f0','#353a41','#a9b1ba','#515860'),
            'High Contrast':('#080808','#ffffff','#111111','#ffff00','#ffffff'),
            'Royal Gold':('#10131a','#f6e9c9','#1d222d','#d5a74a','#57452c'),
            'Cyber Glass':('#081927','#e7faff','#153348','#25c7e5','#326781'),
            'Crystal Light':('#edf4fb','#183653','#ffffff','#3889c9','#c8dae9'),
            'Industrial Pro':('#191e23','#f1f3f4','#292f36','#f29c38','#535c64'),
        }
        bg,fg,panel,accent,border=palettes.get(mode,palettes['هوية الجابر'])
        font=setting('font','Segoe UI').replace('"','')
        if font=='Segoe UI':font={'简体中文':'Microsoft YaHei','বাংলা':'Nirmala UI','اردو':'Nirmala UI'}.get(setting('language','العربية'),font)
        size=int(setting('font_size','12'))
        scale=int(setting('scale','100'))/100
        px=max(10,round(size*scale))
        pad=max(4,round(7*scale))
        btn=max(3,round(4*scale))
        self.setStyleSheet(f"""QMainWindow,QWidget{{background:{bg};color:{fg};font-family:"{font}";font-size:{px}px}}
            QGroupBox{{border:1px solid {border};border-radius:7px;margin-top:12px;padding:{round(7*scale)}px;font-weight:bold;background:{panel}}}
            QGroupBox::title{{subcontrol-origin:margin;left:18px;padding:0 6px}}
            QLineEdit,QComboBox,QDateEdit,QDoubleSpinBox,QSpinBox,QTextEdit{{background:{panel};color:{fg};border:1px solid {border};border-radius:7px;padding:{pad}px;min-height:{round(22*scale)}px}}
            QPushButton{{background:{accent};color:#111111;border:none;border-radius:5px;padding:{btn}px {round(9*scale)}px;font-weight:600}}
            QPushButton:hover{{border:1px solid {fg};background:{accent};padding-top:{max(2,btn-1)}px;padding-bottom:{btn+1}px;}}
            QPushButton:pressed{{background:{panel};color:{fg};border:1px solid {accent};padding-top:{btn+1}px;}}
            QComboBox:hover,QLineEdit:hover,QDateEdit:hover,QDoubleSpinBox:hover,QTextEdit:hover{{border:1px solid {accent};}}
            QLineEdit:focus,QComboBox:focus,QDateEdit:focus,QDoubleSpinBox:focus{{border:2px solid {accent};}}
            QTableWidget::item:hover{{background:{border};}}
            QCheckBox::indicator{{width:14px;height:14px;}}
            QTextEdit#whatsappPreview{{background:#e7ded3;color:#172a27;border:2px solid #25a56a;border-radius:14px;padding:14px;selection-background-color:#78c6a2;}}
            QTableWidget{{background:{panel};color:{fg};alternate-background-color:{bg};gridline-color:{border};selection-background-color:{accent};selection-color:#111}}
            QHeaderView::section{{background:{accent};color:#151515;font-weight:bold;padding:{btn}px;border:1px solid {border}}}
            QTabBar::tab{{background:{panel};color:{fg};padding:{round(6*scale)}px {round(10*scale)}px;border:1px solid {border};border-radius:7px;margin:3px}}
            QTabBar::tab:selected{{background:{accent};color:#111}}""")
        mode_layout=setting('layout_design','industrial')
        design_css={
            'modern': 'QFrame#layoutBanner{background:#ffffff;border:1px solid #cbd5e1;border-radius:12px;} QLabel#metricCard{background:#e8f1fc;color:#1e3a5f;border-radius:9px;padding:14px;} QLabel#brandTitle{color:#1e3a5f;font-weight:bold;font-size:18px;} QTabBar::tab{min-width:0px;text-align:left;}',
            'erp': 'QFrame#layoutBanner{background:#27374b;border-radius:4px;} QLabel#metricCard{background:#344a61;color:#ffffff;border-left:3px solid #ed9d25;padding:12px;} QLabel#brandTitle{color:#ffffff;font-weight:bold;font-size:17px;} QTabBar::tab{min-width:0px;border-radius:2px;}',
            'glass': 'QFrame#layoutBanner{background:#20354b;border:1px solid #4a7891;border-radius:20px;} QLabel#metricCard{background:#2b4a61;color:#effaff;border:1px solid #52849e;border-radius:14px;padding:16px;} QLabel#brandTitle{color:#e9fcff;font-weight:bold;font-size:19px;} QTabBar::tab{border-radius:14px;}',
            'minimal': 'QTabBar::tab{border-radius:0px;margin:0px;padding:7px 14px;} QGroupBox{border-radius:3px;} QPushButton{border-radius:4px;}',
            'industrial': 'QFrame#layoutBanner{background:#282c31;border-left:5px solid #ed9d25;border-radius:6px;} QLabel#metricCard{background:#3a4048;color:#f7f0e7;border-bottom:3px solid #ed9d25;padding:12px;} QLabel#brandTitle{color:#ed9d25;font-weight:bold;font-size:18px;} QTabBar::tab{min-width:0px;}'
        }
        special={
            'Royal Gold':'QGroupBox{border:1px solid #8e7037;border-radius:12px;} QTabBar::tab:selected{border-bottom:3px solid #f0c56b;} QPushButton{border:1px solid #d5a74a;} QLabel#brandTitle{color:#f0c56b;}',
            'Cyber Glass':'QGroupBox{border:1px solid #3a829b;border-radius:16px;} QTabBar::tab:selected{border-bottom:3px solid #4ce2ff;} QPushButton{border:1px solid #55dcf5;} QLabel#brandTitle{color:#70eaff;}',
            'Crystal Light':'QGroupBox{border:1px solid #bad2ea;border-radius:12px;} QTabBar::tab:selected{border-bottom:3px solid #3889c9;} QLabel#brandTitle{color:#23659d;}',
            'Industrial Pro':'QGroupBox{border-left:3px solid #f29c38;border-radius:6px;} QTabBar::tab:selected{border-bottom:3px solid #f29c38;} QLabel#brandTitle{color:#f29c38;}'
        }
        self.setStyleSheet(self.styleSheet()+design_css.get(mode_layout,'')+special.get(mode,'')+" QFrame#layoutBanner{min-height:55px;} QPushButton{min-height:24px;} QTableWidget{border-radius:8px;}")
        for table in self.findChildren(QTableWidget):
            table.verticalHeader().setDefaultSectionSize({'small':25,'medium':33,'large':44}.get(setting('density','medium'),33))
    def refresh_all(self):
        loads=db.execute("""SELECT d.id,c.name,d.day,d.details,d.bem,
            CASE WHEN COALESCE(d.grade2,'')<>'' THEN d.grade||' + '||d.grade2 ELSE d.grade END,
            d.qty+COALESCE(d.qty2,0),d.unit_price,
            d.qty*d.unit_price+COALESCE(d.qty2,0)*COALESCE(d.unit_price2,0),d.notes,d.site_name
            FROM deliveries d JOIN companies c ON c.id=d.company_id
            ORDER BY d.day DESC,d.id DESC""").fetchall()
        self.l_table.setRowCount(len(loads))
        for r,vals in enumerate(loads):
            ordered=[*vals[:3],vals[10] or '',*vals[3:10]]
            for c,v in enumerate(ordered):self.l_table.setItem(r,c,item(money(v) if c in (8,9) else v))
        pays=db.execute('SELECT p.id,c.name,p.day,p.amount,p.note FROM payments p JOIN companies c ON c.id=p.company_id ORDER BY p.day DESC,p.id DESC').fetchall()
        self.p_table.setRowCount(len(pays))
        for r,vals in enumerate(pays):
            for c,v in enumerate(vals):self.p_table.setItem(r,c,item(money(v) if c==3 else v))
        self.update_summary();self.refresh_company_pages();self.refresh_export_preview();self.refresh_whatsapp_inline();self.refresh_layout_metrics()

if __name__=='__main__':
    try:
        app=QApplication(sys.argv)
        app.setLayoutDirection(Qt.RightToLeft)
        w=App()
        w.show()
        sys.exit(app.exec())
    except Exception:
        message=traceback.format_exc()
        try:
            (APP_DIR/'startup_error.log').write_text(message,encoding='utf-8')
        except Exception:
            (Path.home()/'ALJABER_startup_error.log').write_text(message,encoding='utf-8')
        print(message,file=sys.stderr)
        try:
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.critical(None,'AL-JABER Startup Error',message[-3500:])
        except Exception:
            pass
        sys.exit(1)

