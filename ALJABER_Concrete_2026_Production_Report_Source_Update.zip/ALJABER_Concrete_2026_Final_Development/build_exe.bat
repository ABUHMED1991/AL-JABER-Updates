﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
py -m pip install --upgrade PySide6 xlsxwriter reportlab arabic-reshaper python-bidi pyinstaller
if errorlevel 1 (echo ERROR: Python dependencies could not be installed & pause & exit /b 1)
py -m PyInstaller --noconfirm --clean --onefile --console --name ALJABER_Concrete_2026 --runtime-hook startup_hook.py --hidden-import translations --hidden-import production_report --collect-all PySide6 --collect-all reportlab --collect-all arabic_reshaper --collect-all bidi --distpath "%~dp0dist" --workpath "%~dp0build_portable" app.py
if errorlevel 1 (echo ERROR: EXE build failed & pause & exit /b 1)
if not exist "ALJABER_Concrete_2026_PORTABLE" mkdir "ALJABER_Concrete_2026_PORTABLE"
if not exist "ALJABER_Concrete_2026_PORTABLE\data" mkdir "ALJABER_Concrete_2026_PORTABLE\data"
copy /Y "dist\ALJABER_Concrete_2026.exe" "ALJABER_Concrete_2026_PORTABLE\ALJABER_Concrete_2026.exe" >nul
copy /Y "aljaber_logo.png" "ALJABER_Concrete_2026_PORTABLE\aljaber_logo.png" >nul
copy /Y "PORTABLE_README_AR.txt" "ALJABER_Concrete_2026_PORTABLE\README_AR.txt" >nul
copy /Y "diagnose.bat" "ALJABER_Concrete_2026_PORTABLE\diagnose.bat" >nul
echo PORTABLE BUILD READY. COPY THE WHOLE ALJABER_Concrete_2026_PORTABLE FOLDER.
pause
