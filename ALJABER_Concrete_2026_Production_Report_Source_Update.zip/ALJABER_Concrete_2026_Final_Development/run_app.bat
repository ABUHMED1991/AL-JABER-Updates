@echo off
cd /d "%~dp0"
py -m pip install PySide6 xlsxwriter reportlab arabic-reshaper python-bidi
py app.py
pause
