﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo AL-JABER Concrete 2026 - Startup Diagnostic
echo Windows: %OS% %PROCESSOR_ARCHITECTURE%
echo Starting application...
"%~dp0ALJABER_Concrete_2026.exe" > "%TEMP%\ALJABER_Concrete_console.log" 2>&1
echo.
echo Exit code: %ERRORLEVEL%
echo --- Startup output ---
type "%TEMP%\ALJABER_Concrete_console.log"
echo.
echo If it failed, send startup_error.log (if present) or the text above.
pause
