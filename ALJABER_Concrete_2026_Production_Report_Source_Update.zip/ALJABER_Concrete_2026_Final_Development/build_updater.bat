@echo off
setlocal
cd /d "%~dp0"
py -m pip install pyinstaller
if errorlevel 1 (echo ERROR installing PyInstaller & pause & exit /b 1)
py -m PyInstaller --noconfirm --clean --onefile --windowed --name UPDATER --distpath "%~dp0dist" --workpath "%~dp0build_updater" updater.py
if errorlevel 1 (echo ERROR building UPDATER & pause & exit /b 1)
if not exist "ALJABER_Concrete_2026_PORTABLE" mkdir "ALJABER_Concrete_2026_PORTABLE"
copy /Y "dist\UPDATER.exe" "ALJABER_Concrete_2026_PORTABLE\UPDATER.exe" >nul
echo UPDATER.exe created successfully.
pause
