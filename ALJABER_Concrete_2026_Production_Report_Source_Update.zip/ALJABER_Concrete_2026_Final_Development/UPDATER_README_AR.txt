AL-JABER Concrete 2026 | UPDATER
Developed by ABUHMED1991

الملفات:
app.py / translations.py : مصدر البرنامج الرئيسي
updater.py : أداة التحديث المستقلة (Python standard library only)
build_exe.bat : بناء البرنامج الرئيسي EXE
build_updater.bat : بناء UPDATER.exe
build_all.bat : بناء الاثنين
run_updater.bat : تشغيل أداة التحديث عبر Python

التثبيت لأول مرة:
1. على Windows مع Python شغّل build_exe.bat ثم build_updater.bat.
2. انسخ ALJABER_Concrete_2026.exe و UPDATER.exe إلى مجلد البرنامج المحمول.
3. لا تحذف مجلد data أو ملف concrete.db.

للتحديثات اللاحقة:
1. أغلق البرنامج الرئيسي.
2. شغّل UPDATER.exe واختر مجلد البرنامج وملف update ZIP المتوافق.
3. تفحص الأداة محتويات ZIP وبصمات SHA256 وتمنع استبدال data.
4. تحفظ نسخة من ملفات البرنامج وقاعدة البيانات قبل التحديث.
5. يمكن استعادة ملفات البرنامج من نسخة سابقة؛ لا تعيد الأداة قاعدة البيانات تلقائياً لتجنب فقد البيانات الجديدة.

ملاحظة: التحقق بالبصمات يكشف تلف الملفات لكنه لا يثبت هوية الناشر.
لا تثبّت تحديثات من جهات غير موثوقة. ملف ZIP الكامل للمصدر ليس حزمة تحديث UPDATER.
حزمة التحديث المناسبة تُنشأ باستخدام make_update.py.

ملاحظة اختبار: تم فحص تركيب ملفات Python واختبار آلية التحديث والاستعادة آلياً.
لم يتم اختبار واجهة PySide6 أو ملفات EXE على Windows في هذه البيئة.
