import sys, traceback, os
from pathlib import Path

def log_unhandled(exc_type,exc_value,exc_tb):
    details=''.join(traceback.format_exception(exc_type,exc_value,exc_tb))
    folder=Path(sys.executable).resolve().parent
    try:(folder/'startup_error.log').write_text(details,encoding='utf-8')
    except Exception:
        try:(Path.home()/'ALJABER_startup_error.log').write_text(details,encoding='utf-8')
        except Exception:pass
    sys.__stderr__.write(details)
sys.excepthook=log_unhandled
