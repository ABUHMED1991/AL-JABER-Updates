"""Standalone production report; never writes to deliveries or payments."""
import csv
from collections import defaultdict
from datetime import datetime
from PySide6.QtCore import Qt, QDate, QTimer
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QComboBox,QPushButton,
    QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QMessageBox,QFileDialog,
    QDateEdit,QLineEdit,QDoubleSpinBox,QFormLayout,QGroupBox,QStackedWidget,QGridLayout,QCheckBox)

HEADERS=['Date','End Time','Waybill No','Customer','M³','Recipe Name','Vehicle','Driver']
FIELDS=['day','end_time','waybill','customer','qty','recipe','vehicle','driver']

class ProductionReport(QWidget):
    def __init__(self,db,setting,set_setting,parent=None):
        super().__init__(parent);self.db=db;self.setting=setting;self.set_setting=set_setting
        self.db.execute('''CREATE TABLE IF NOT EXISTS production_records (
          id INTEGER PRIMARY KEY,day TEXT NOT NULL,end_time TEXT DEFAULT '',waybill TEXT DEFAULT '',
          customer TEXT NOT NULL,qty REAL NOT NULL DEFAULT 0,recipe TEXT DEFAULT '',
          vehicle TEXT DEFAULT '',driver TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP)''');self.db.commit()
        self._loading=False;self._rowids={};self._edit_id=None
        root=QVBoxLayout(self);root.setContentsMargins(10,8,10,8);root.setSpacing(5)
        bar=QHBoxLayout();title=QLabel('Production Report');title.setStyleSheet('font-size:17px;font-weight:700');bar.addWidget(title)
        bar.addStretch();bar.addWidget(QLabel('طريقة العرض:'))
        self.mode=QComboBox();self.mode.addItem('التقرير الورقي | Paper','paper');self.mode.addItem('البطاقات | Cards','cards');self.mode.addItem('نموذج الإدخال | Form','form')
        self.mode.setCurrentIndex(max(0,self.mode.findData(self.setting('production_mode','paper'))));bar.addWidget(self.mode)
        self.compact=QCheckBox('عرض مدمج');self.compact.setChecked(self.setting('production_compact','1')=='1');bar.addWidget(self.compact)
        root.addLayout(bar)
        tools=QHBoxLayout();self.company_filter=QComboBox();tools.addWidget(QLabel('الشركة:'));tools.addWidget(self.company_filter)
        self.day_filter=QDateEdit();self.day_filter.setCalendarPopup(True);self.day_filter.setDisplayFormat('dd.MM.yyyy');self.day_filter.setDate(QDate.currentDate());tools.addWidget(QLabel('التاريخ:'));tools.addWidget(self.day_filter)
        self.all_dates=QCheckBox('كل التواريخ');self.all_dates.setChecked(True);tools.addWidget(self.all_dates)
        tools.addStretch()
        for text,handler in [('+ إضافة سطر',self.add_row),('حذف سطر',self.delete_row),('Excel',self.export_xlsx),('PDF',self.export_pdf)]:
            b=QPushButton(text);b.clicked.connect(handler);tools.addWidget(b)
        root.addLayout(tools)
        self.stack=QStackedWidget();root.addWidget(self.stack,1)
        paper=QWidget();pv=QVBoxLayout(paper);pv.setContentsMargins(0,0,0,0)
        self.paper=QTableWidget();self.setup_table(self.paper);self.paper.itemChanged.connect(self.edit_cell);pv.addWidget(self.paper,1)
        self.paper_total=QLabel();pv.addWidget(self.paper_total);self.stack.addWidget(paper)
        cards=QWidget();cv=QVBoxLayout(cards);cv.setContentsMargins(0,0,0,0)
        self.card_table=QTableWidget();self.setup_table(self.card_table);self.card_table.itemChanged.connect(self.edit_cell);cv.addWidget(self.card_table,1)
        self.card_total=QLabel();cv.addWidget(self.card_total);self.stack.addWidget(cards)
        formpage=QWidget();fv=QVBoxLayout(formpage);fv.setContentsMargins(0,0,0,0)
        group=QGroupBox('إضافة / تعديل سجل الإنتاج');fg=QGridLayout(group);self.inputs={}
        for i,(field,label) in enumerate(zip(FIELDS,HEADERS)):
            fg.addWidget(QLabel(label),i//4*2,i%4)
            if field=='day':w=QDateEdit();w.setCalendarPopup(True);w.setDisplayFormat('dd.MM.yyyy');w.setDate(QDate.currentDate())
            elif field=='qty':w=QDoubleSpinBox();w.setRange(0,100000);w.setDecimals(2)
            else:w=QLineEdit()
            self.inputs[field]=w;fg.addWidget(w,i//4*2+1,i%4)
        actions=QHBoxLayout();save=QPushButton('إدراج / تحديث');save.clicked.connect(self.save_form);actions.addWidget(save)
        clear=QPushButton('سجل جديد');clear.clicked.connect(self.clear_form);actions.addWidget(clear);actions.addStretch()
        fv.addWidget(group);fv.addLayout(actions)
        self.form_table=QTableWidget();self.setup_table(self.form_table);self.form_table.itemChanged.connect(self.edit_cell)
        self.form_table.itemDoubleClicked.connect(self.select_form_row);fv.addWidget(self.form_table,1)
        self.form_total=QLabel();fv.addWidget(self.form_total);self.stack.addWidget(formpage)
        self.mode.currentIndexChanged.connect(self.change_mode);self.compact.toggled.connect(self.change_compact)
        self.company_filter.currentIndexChanged.connect(self.refresh);self.day_filter.dateChanged.connect(self.refresh);self.all_dates.toggled.connect(self.refresh)
        self.refresh_filters();self.change_mode()

    def setup_table(self,table):
        table.setColumnCount(8);table.setHorizontalHeaderLabels(HEADERS)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        table.setColumnWidth(0,105);table.setColumnWidth(1,100);table.setColumnWidth(2,105)
        table.setColumnWidth(3,190);table.setColumnWidth(4,85);table.setColumnWidth(5,115)
        table.setColumnWidth(6,115);table.setColumnWidth(7,170)
        table.setSelectionBehavior(QAbstractItemView.SelectRows);table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.setAlternatingRowColors(False);table.verticalHeader().hide()
        table.setEditTriggers(QAbstractItemView.DoubleClicked|QAbstractItemView.EditKeyPressed)

    def refresh_filters(self):
        old=self.company_filter.currentText();self.company_filter.blockSignals(True);self.company_filter.clear();self.company_filter.addItem('جميع الشركات','')
        names=[r[0] for r in self.db.execute('SELECT DISTINCT customer FROM production_records UNION SELECT name FROM companies ORDER BY 1')]
        for name in names:self.company_filter.addItem(name,name)
        idx=self.company_filter.findText(old)
        if idx>=0:self.company_filter.setCurrentIndex(idx)
        self.company_filter.blockSignals(False)

    def rows(self):
        query='SELECT id,day,end_time,waybill,customer,qty,recipe,vehicle,driver FROM production_records WHERE 1=1';args=[]
        if self.company_filter.currentData():query+=' AND customer=?';args.append(self.company_filter.currentData())
        if not self.all_dates.isChecked():query+=' AND day=?';args.append(self.day_filter.date().toString('yyyy-MM-dd'))
        query+=' ORDER BY customer COLLATE NOCASE,day,end_time,id'
        return self.db.execute(query,args).fetchall()

    def refresh(self,*_):
        rows=self.rows();groups=defaultdict(list)
        for r in rows:groups[r[4]].append(r)
        self._loading=True
        try:
            for table in (self.paper,self.card_table,self.form_table):
                table.blockSignals(True);table.setRowCount(0)
                mapping={};position=0
                for name,records in groups.items():
                    if table is self.card_table:
                        table.insertRow(position);table.setSpan(position,0,1,8)
                        h=QTableWidgetItem(f'▣  {name}     |     {len(records)} وصولات');h.setFlags(Qt.ItemIsEnabled);table.setItem(position,0,h);position+=1
                    for record in records:
                        table.insertRow(position);mapping[position]=record[0]
                        vals=[record[1],record[2],record[3],record[4],record[5],record[6],record[7],record[8]]
                        for col,value in enumerate(vals):
                            if col==0:value=datetime.strptime(value,'%Y-%m-%d').strftime('%d.%m.%y')
                            cell=QTableWidgetItem(str(value));cell.setTextAlignment(Qt.AlignCenter)
                            table.setItem(position,col,cell)
                        position+=1
                    table.insertRow(position)
                    for col,value in ((3,'Total Produced'),(4,f'{sum(float(r[5]) for r in records):g}')):
                        cell=QTableWidgetItem(value);cell.setFlags(Qt.ItemIsEnabled);font=cell.font();font.setBold(True);cell.setFont(font);table.setItem(position,col,cell)
                    position+=1
                    if table is self.paper:
                        table.insertRow(position);table.setRowHeight(position,9);position+=1
                self._rowids[id(table)]=mapping
                table.blockSignals(False)
                table.verticalHeader().setDefaultSectionSize(23 if self.compact.isChecked() else 32)
            total=sum(float(r[5]) for r in rows)
            for label in (self.paper_total,self.card_total,self.form_total):label.setText(f'Total Produced Quantity: {total:g} M³     |     {len(rows)} Waybills')
        finally:self._loading=False

    def change_mode(self,*_):
        mode=self.mode.currentData();self.stack.setCurrentIndex({'paper':0,'cards':1,'form':2}[mode]);self.set_setting('production_mode',mode)
    def change_compact(self,*_):
        self.set_setting('production_compact','1' if self.compact.isChecked() else '0');self.refresh()
    def current_record(self):
        table=(self.paper,self.card_table,self.form_table)[self.stack.currentIndex()]
        return self._rowids.get(id(table),{}).get(table.currentRow())
    def add_row(self):
        name=self.company_filter.currentData()
        if not name:
            names=[r[0] for r in self.db.execute('SELECT name FROM companies ORDER BY name')]
            if not names:QMessageBox.warning(self,'Production Report','أضف شركة أولاً من صفحة الشركات.');return
            name=names[0]
        self.db.execute('INSERT INTO production_records(day,end_time,waybill,customer,qty,recipe,vehicle,driver) VALUES(?,?,?,?,?,?,?,?)',
            (self.day_filter.date().toString('yyyy-MM-dd'),'','',''+name,0,'','',''))
        self.db.commit();self.refresh_filters();self.refresh()
    def edit_cell(self,cell):
        if self._loading:return
        table=cell.tableWidget() if hasattr(cell,'tableWidget') else None
        if table is None:
            for candidate in (self.paper,self.card_table,self.form_table):
                if candidate.item(cell.row(),cell.column()) is cell:table=candidate;break
        if table is None:return
        rid=self._rowids.get(id(table),{}).get(cell.row())
        if rid is None:return
        col=cell.column();value=cell.text().strip()
        if col==0:
            try:value=datetime.strptime(value,'%d.%m.%y').strftime('%Y-%m-%d')
            except ValueError:
                try:value=datetime.strptime(value,'%Y-%m-%d').strftime('%Y-%m-%d')
                except ValueError:QMessageBox.warning(self,'التاريخ','استخدم dd.mm.yy أو yyyy-mm-dd');self.refresh();return
        if col==4:
            try:value=float(value.replace(',','.'))
            except ValueError:QMessageBox.warning(self,'الكمية','أدخل رقماً صحيحاً');self.refresh();return
            if value<0:QMessageBox.warning(self,'الكمية','الكمية لا يمكن أن تكون سالبة');self.refresh();return
        if col==3 and not value:QMessageBox.warning(self,'الشركة','اسم الشركة مطلوب');self.refresh();return
        self.db.execute(f'UPDATE production_records SET {FIELDS[col]}=? WHERE id=?',(value,rid));self.db.commit()
        self.refresh_filters();self.refresh()
    def delete_row(self):
        rid=self.current_record()
        if rid is None:return
        if QMessageBox.question(self,'تأكيد الحذف','هل تريد حذف سطر الإنتاج المحدد؟')!=QMessageBox.Yes:return
        self.db.execute('DELETE FROM production_records WHERE id=?',(rid,));self.db.commit();self.refresh()
    def select_form_row(self,item):
        rid=self._rowids.get(id(self.form_table),{}).get(item.row())
        if rid is None:return
        r=self.db.execute('SELECT day,end_time,waybill,customer,qty,recipe,vehicle,driver FROM production_records WHERE id=?',(rid,)).fetchone()
        self._edit_id=rid
        for field,value in zip(FIELDS,r):
            w=self.inputs[field]
            if field=='day':w.setDate(QDate.fromString(value,'yyyy-MM-dd'))
            elif field=='qty':w.setValue(value)
            else:w.setText(str(value))
    def clear_form(self):
        self._edit_id=None
        for field,w in self.inputs.items():
            if field=='day':w.setDate(QDate.currentDate())
            elif field=='qty':w.setValue(0)
            else:w.clear()
    def save_form(self):
        vals=[]
        for field,w in self.inputs.items():
            vals.append(w.date().toString('yyyy-MM-dd') if field=='day' else w.value() if field=='qty' else w.text().strip())
        if not vals[3]:QMessageBox.warning(self,'Production Report','أدخل اسم الشركة');return
        if self._edit_id is None:self.db.execute('INSERT INTO production_records(day,end_time,waybill,customer,qty,recipe,vehicle,driver) VALUES(?,?,?,?,?,?,?,?)',vals)
        else:self.db.execute('UPDATE production_records SET day=?,end_time=?,waybill=?,customer=?,qty=?,recipe=?,vehicle=?,driver=? WHERE id=?',(*vals,self._edit_id))
        self.db.commit();self.clear_form();self.refresh_filters();self.refresh()
    def export_xlsx(self):
        path,_=QFileDialog.getSaveFileName(self,'Production Report Excel','Production_Report.xlsx','Excel (*.xlsx)')
        if not path:return
        try:
            import xlsxwriter
            wb=xlsxwriter.Workbook(path);ws=wb.add_worksheet('Production Report');ws.set_landscape();ws.fit_to_pages(1,0)
            head=wb.add_format({'bold':True,'border':1,'bg_color':'#E9ECEF','align':'center'});cell=wb.add_format({'border':1,'align':'center'});total=wb.add_format({'bold':True,'border':1})
            for col,h in enumerate(HEADERS):ws.write(0,col,h,head);ws.set_column(col,col,[14,13,15,26,10,17,16,23][col])
            rnum=1;groups=defaultdict(list)
            for r in self.rows():groups[r[4]].append(r)
            for name,records in groups.items():
                for r in records:
                    for col,v in enumerate(r[1:]):ws.write(rnum,col,v,cell)
                    rnum+=1
                ws.write(rnum,3,'Total Produced',total);ws.write_number(rnum,4,sum(float(r[5]) for r in records),total);rnum+=2
            ws.write(rnum,3,'Total Produced Quantity',total);ws.write_number(rnum,4,sum(float(r[5]) for r in self.rows()),total)
            wb.close()
        except Exception as exc:QMessageBox.critical(self,'Excel',str(exc))
    def export_pdf(self):
        path,_=QFileDialog.getSaveFileName(self,'Production Report PDF','Production_Report.pdf','PDF (*.pdf)')
        if not path:return
        try:
            from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer
            from reportlab.lib import colors
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.lib.pagesizes import A4,landscape
            data=[HEADERS];groups=defaultdict(list)
            for r in self.rows():groups[r[4]].append(r)
            for name,records in groups.items():
                for r in records:data.append([str(v) for v in r[1:]])
                data.append(['','','','Total Produced',f'{sum(float(r[5]) for r in records):g}','','',''])
                data.append(['']*8)
            data.append(['','','','Total Produced Quantity',f'{sum(float(r[5]) for r in self.rows()):g}','','',''])
            doc=SimpleDocTemplate(path,pagesize=landscape(A4),leftMargin=15,rightMargin=15,topMargin=22,bottomMargin=20)
            widths=[73,67,72,150,45,86,72,125]
            t=Table(data,colWidths=widths,repeatRows=1)
            t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.4,colors.grey),('BACKGROUND',(0,0),(-1,0),colors.whitesmoke),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),8),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
            doc.build([Paragraph('Production Report',getSampleStyleSheet()['Heading2']),Spacer(1,8),t])
        except Exception as exc:QMessageBox.critical(self,'PDF',str(exc))
