"""UPDATER: offline signed-by-hash update packages for AL-JABER Concrete 2026.

No arbitrary commands or scripts are run from update packages. Hashes detect damage,
not publisher identity: obtain packages only from a trusted source.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime

APP_NAME = 'ALJABER_Concrete_2026.exe'
PROTECTED = {'data', 'backups', '.updater_backups', 'updates'}
ALLOWED_TOP = {APP_NAME, 'README_AR.txt', 'PORTABLE_README_AR.txt', 'diagnose.bat', 'startup_hook.py', 'app.py', 'translations.py', 'run_app.bat', 'build_exe.bat'}


def sha256(blob):
    return hashlib.sha256(blob).hexdigest()


def safe_name(name):
    if not isinstance(name, str) or not name or '\\' in name or '\x00' in name:
        raise ValueError('Unsafe file name')
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or len(p.parts) != 1 or ':' in name:
        raise ValueError('Unsafe file path: ' + name)
    if p.parts[0].lower() in PROTECTED or name not in ALLOWED_TOP:
        raise ValueError('File not allowed in update: ' + name)
    return name


def validate_package(package):
    with zipfile.ZipFile(package) as archive:
        infos = archive.infolist()
        if len(infos) > 40 or sum(i.file_size for i in infos) > 300 * 1024 * 1024:
            raise ValueError('Update package too large')
        if len({i.filename for i in infos}) != len(infos):
            raise ValueError('Duplicate archive entries')
        manifest = json.loads(archive.read('manifest.json'))
        if manifest.get('product') != 'AL-JABER Concrete 2026' or manifest.get('schema') != 1:
            raise ValueError('Incompatible update package')
        files = manifest.get('files')
        if not isinstance(files, dict) or not files:
            raise ValueError('Missing update file list')
        if set(i.filename for i in infos) != set(files) | {'manifest.json'}:
            raise ValueError('Archive file list differs from manifest')
        for filename, digest in files.items():
            safe_name(filename)
            info = archive.getinfo(filename)
            if info.is_dir() or (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError('Links and directories are not allowed')
            if not isinstance(digest, str) or len(digest) != 64 or sha256(archive.read(filename)) != digest:
                raise ValueError('Hash verification failed: ' + filename)
        return manifest


def process_alive(name=APP_NAME):
    if sys.platform != 'win32':
        return False
    import subprocess
    result = subprocess.run(['tasklist', '/FI', f'IMAGENAME eq {name}', '/FO', 'CSV', '/NH'],
                            capture_output=True, text=True, check=False)
    return name.lower() in result.stdout.lower()


def install(package, target, progress=lambda _: None):
    target = Path(target).resolve()
    if not target.is_dir():
        raise ValueError('Select an existing program directory')
    manifest = validate_package(package)
    if process_alive():
        raise RuntimeError('Close ALJABER_Concrete_2026.exe before updating')
    files = manifest['files']
    backup_root = target / '.updater_backups'
    backup_root.mkdir(exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup = backup_root / stamp
    backup.mkdir()
    prior = {}
    # Backup database separately, with SQLite online backup if it exists.
    db_path = target / 'data' / 'concrete.db'
    if db_path.exists():
        import sqlite3
        data_backup = backup / 'concrete.db'
        source_db = sqlite3.connect(f'file:{db_path.as_posix()}?mode=ro', uri=True)
        dest_db = sqlite3.connect(data_backup)
        try:
            source_db.backup(dest_db)
        finally:
            dest_db.close(); source_db.close()
    try:
        with zipfile.ZipFile(package) as archive:
            for filename in files:
                old = target / filename
                prior[filename] = old.exists()
                if old.exists():
                    shutil.copy2(old, backup / filename)
            (backup / 'rollback.json').write_text(json.dumps({'files': prior, 'version': manifest.get('version','')}, indent=2), encoding='utf-8')
            for filename in files:
                progress('Installing ' + filename)
                destination = target / filename
                fd, tempname = tempfile.mkstemp(prefix='.updater_', dir=target)
                try:
                    with os.fdopen(fd, 'wb') as out:
                        out.write(archive.read(filename))
                        out.flush(); os.fsync(out.fileno())
                    os.replace(tempname, destination)
                finally:
                    if os.path.exists(tempname):os.unlink(tempname)
        (target / 'version.json').write_text(json.dumps({'version':manifest.get('version',''), 'installed':stamp}, indent=2), encoding='utf-8')
        progress('Update installed. Backup: ' + str(backup))
        return backup
    except Exception:
        for filename, existed in prior.items():
            destination = target / filename
            if existed and (backup / filename).exists():
                shutil.copy2(backup / filename, destination)
            elif not existed and destination.exists():
                destination.unlink()
        raise


def rollback(backup, target):
    backup, target = Path(backup).resolve(), Path(target).resolve()
    if not backup.is_dir() or backup.parent != target / '.updater_backups':
        raise ValueError('Invalid backup location')
    if process_alive():
        raise RuntimeError('Close the main program before restoring')
    manifest = json.loads((backup / 'rollback.json').read_text(encoding='utf-8'))
    for filename, existed in manifest['files'].items():
        safe_name(filename)
        dest = target / filename
        if existed:
            shutil.copy2(backup / filename, dest)
        elif dest.exists():
            dest.unlink()
    # Do not roll back database automatically: preserve any work since update.
    return True


def gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    root = tk.Tk(); root.title('UPDATER'); root.geometry('650x400'); root.minsize(540,360)
    root.configure(bg='#20252d')
    style=ttk.Style(root);style.theme_use('clam')
    style.configure('TFrame',background='#20252d');style.configure('TLabel',background='#20252d',foreground='#f5f5f5',font=('Segoe UI',10))
    frame=ttk.Frame(root,padding=20);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='UPDATER',font=('Segoe UI',22,'bold')).pack(anchor='w')
    ttk.Label(frame,text='AL-JABER Concrete 2026  •  Developed by ABUHMED1991').pack(anchor='w',pady=(0,18))
    path=tk.StringVar(value=str(Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent))
    pkg=tk.StringVar()
    ttk.Label(frame,text='Program folder / مجلد البرنامج').pack(anchor='w')
    folder_row=ttk.Frame(frame);folder_row.pack(fill='x',pady=4)
    ttk.Entry(folder_row,textvariable=path).pack(side='left',fill='x',expand=True)
    ttk.Button(folder_row,text='Browse',command=lambda:path.set(filedialog.askdirectory(initialdir=path.get()) or path.get())).pack(side='left',padx=5)
    ttk.Label(frame,text='Update package / ملف التحديث ZIP').pack(anchor='w',pady=(12,0))
    package_row=ttk.Frame(frame);package_row.pack(fill='x',pady=4)
    ttk.Entry(package_row,textvariable=pkg).pack(side='left',fill='x',expand=True)
    ttk.Button(package_row,text='Browse',command=lambda:pkg.set(filedialog.askopenfilename(filetypes=[('Update ZIP','*.zip')]) or pkg.get())).pack(side='left',padx=5)
    status=tk.StringVar(value='Ready. Close the main program before updating.')
    ttk.Label(frame,textvariable=status,wraplength=580).pack(anchor='w',pady=15)
    actions=ttk.Frame(frame);actions.pack(fill='x')
    def do_install():
        try:
            if not pkg.get():raise ValueError('Choose an update ZIP')
            m=validate_package(pkg.get())
            if not messagebox.askyesno('Confirm update',f"Install version {m.get('version','unknown')}?\nA backup will be created."):
                return
            backup=install(pkg.get(),path.get(),lambda text:(status.set(text),root.update_idletasks()))
            messagebox.showinfo('Success','Update installed successfully.\nBackup: '+str(backup))
        except Exception as ex:messagebox.showerror('Update failed',str(ex))
    def do_rollback():
        folder=Path(path.get())/'.updater_backups'
        chosen=filedialog.askdirectory(initialdir=str(folder) if folder.exists() else path.get(),title='Choose previous backup')
        if not chosen:return
        if messagebox.askyesno('Restore previous version','Restore program files from this backup?\nDatabase will NOT be overwritten.'):
            try:rollback(chosen,path.get());messagebox.showinfo('Success','Previous program files restored.')
            except Exception as ex:messagebox.showerror('Restore failed',str(ex))
    ttk.Button(actions,text='Install update',command=do_install).pack(side='left',padx=(0,10))
    ttk.Button(actions,text='Restore previous version',command=do_rollback).pack(side='left')
    ttk.Label(frame,text='Only install update packages from a trusted source. Your data folder is never replaced.',wraplength=550).pack(anchor='w',pady=20)
    root.mainloop()

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--check')
    parser.add_argument('--install')
    parser.add_argument('--rollback')
    parser.add_argument('--target',default=str(Path(__file__).resolve().parent))
    args=parser.parse_args()
    if args.check:print(json.dumps(validate_package(args.check),ensure_ascii=False,indent=2))
    elif args.install:print('Backup:',install(args.install,args.target))
    elif args.rollback:print('Restored:',rollback(args.rollback,args.target))
    else:gui()
